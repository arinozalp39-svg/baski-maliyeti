#!/bin/bash
source /opt/wasmtc/env.sh
export CMAKE_POLICY_VERSION_MINIMUM=3.5 EMSDK=/opt/emsdk
D=/opt/wasmtc/deps-install; W=/opt/wasmtc/bblwasm
emcmake cmake -S /opt/wasmtc/bsrc -B /opt/wasmtc/bbuild -G Ninja -DCMAKE_BUILD_TYPE=Release \
 -DCMAKE_PREFIX_PATH=$D -DCMAKE_MODULE_PATH=$W/cmake -DCMAKE_PROJECT_INCLUDE_BEFORE=$W/cmake/wasm_find_paths.cmake \
 -DSLIC3R_WASM=ON -DSLIC3R_GUI=OFF -DSLIC3R_STATIC=ON -DSLIC3R_PCH=OFF -DBBL_WASM_DIR=$W -DTBB_SHIM_DIR=$W/shims \
 -DBBL_RELEASE_TO_PUBLIC=1 -DBBL_INTERNAL_TESTING=0 \
 -DBoost_NO_SYSTEM_PATHS=ON -DBoost_NO_BOOST_CMAKE=ON -DBOOST_ROOT=$D -DBoost_ROOT=$D -DCGAL_DIR=$D/lib/cmake/CGAL \
 -DNLOPT_LIBRARY=$D/lib/libnlopt_cxx.a -DNLOPT_INCLUDE_DIR=$D/include \
 "-DCMAKE_CXX_FLAGS=-I$W/shims -DBOOST_HAS_PTHREADS=1 -DSLIC3R_WASM=1 -DSLIC3R_NO_OPENVDB=1 -DSLIC3R_NO_OPENCV=1 -fwasm-exceptions -Wno-unknown-warning-option" \
 "-DCMAKE_C_FLAGS=-I$W/shims -sSUPPORT_LONGJMP=wasm -fwasm-exceptions" 2>&1 | grep -v "^--\|^$" | grep -iv "deprecat\|policy\|compatib\|Update the VERSION\|CMake that the\|Call Stack\|warning (dev)\|developers" | head -60
