#!/bin/bash
source /opt/wasmtc/env.sh
ulimit -s unlimited
cd /opt/wasmtc/bbuild
ninja -k 0 -j2 bambu_slicer > /opt/wasmtc/build.log 2>&1
echo "EXIT $?" >> /opt/wasmtc/build.log
