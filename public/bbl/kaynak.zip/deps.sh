#!/bin/bash
set -e
source /opt/wasmtc/env.sh
export CMAKE_POLICY_VERSION_MINIMUM=3.5
INSTALL=/opt/wasmtc/deps-install; mkdir -p $INSTALL; DL=/opt/wasmtc/dl; mkdir -p $DL
XC="-fwasm-exceptions"; XCC="-sSUPPORT_LONGJMP=wasm -fwasm-exceptions"
J=2
step(){ echo "=== $1 $(date +%T)"; }
# ── Boost 1.84 ─────────────────────────────────
if [ ! -f $INSTALL/.boost ]; then step boost
 cd $DL; [ -d boost-1.84.0 ] || { curl -fsSL https://github.com/boostorg/boost/releases/download/boost-1.84.0/boost-1.84.0.tar.gz | tar xz; }
 cd boost-1.84.0; ./bootstrap.sh --with-toolset=clang >/dev/null
 printf "using clang : emscripten : em++ :\n<archiver>emar\n<ranlib>emranlib ;\n" > ~/user-config.jam
 ./b2 toolset=clang-emscripten variant=release link=static threading=single --layout=system --prefix=$INSTALL \
  --with-atomic --with-chrono --with-date_time --with-filesystem --with-iostreams --with-locale --with-log --with-nowide \
  --with-program_options --with-regex --with-system --with-thread \
  define=BOOST_LOG_WITHOUT_SYSLOG=1 define=BOOST_LOG_NO_THREADS=1 define=BOOST_THREAD_DONT_USE_PTHREAD=1 \
  "cxxflags=$XC" -j$J install > $DL/boost.log 2>&1 || { tail -30 $DL/boost.log; exit 1; }
 touch $INSTALL/.boost; fi
# ── GMP / MPFR ─────────────────────────────────
if [ ! -f $INSTALL/.gmp ]; then step gmp
 cd $DL; rm -rf gmp-6.3.0*; tar xJf /tmp/src/gmp_6.3.0+dfsg.orig.tar.xz; cd gmp-6.3.0*
 mkdir -p doc; [ -f doc/Makefile.in ] || printf 'all:\ninstall:\nclean:\ndistclean:\ncheck:\ninstall-data:\ninstall-exec:\nuninstall:\n' > doc/Makefile.in
 export gmp_cv_asm_label_suffix=":"; printf 'gmp_cv_asm_label_suffix=":"\n' > /tmp/gmp_site.sh
 CFLAGS="$XCC" CXXFLAGS="$XC" CONFIG_SITE=/tmp/gmp_site.sh emconfigure ./configure --prefix=$INSTALL --host=wasm32-unknown-emscripten \
   --disable-shared --enable-static --disable-assembly --enable-cxx > $DL/gmp.log 2>&1
 emmake make -j$J >> $DL/gmp.log 2>&1 && make install >> $DL/gmp.log 2>&1 || { tail -30 $DL/gmp.log; exit 1; }
 touch $INSTALL/.gmp; fi
if [ ! -f $INSTALL/.mpfr ]; then step mpfr
 cd $DL; rm -rf mpfr-4.2.1; tar xJf /tmp/src/mpfr4_4.2.1.orig.tar.xz; cd mpfr-4.2.1
 CFLAGS="$XCC" emconfigure ./configure --prefix=$INSTALL --with-gmp=$INSTALL --disable-shared --enable-static --host=wasm32-unknown-emscripten > $DL/mpfr.log 2>&1
 emmake make -j$J >> $DL/mpfr.log 2>&1 && make install >> $DL/mpfr.log 2>&1 || { tail -30 $DL/mpfr.log; exit 1; }
 touch $INSTALL/.mpfr; fi
# ── CGAL 5.6.2 headers ─────────────────────────
if [ ! -f $INSTALL/.cgal ]; then step cgal
 cd $DL; [ -d CGAL-5.6.2 ] || curl -fsSL https://github.com/CGAL/cgal/releases/download/v5.6.2/CGAL-5.6.2.tar.xz | tar xJ
 cmake -S CGAL-5.6.2 -B cgal-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DCMAKE_BUILD_TYPE=Release \
  -DGMP_INCLUDE_DIR=$INSTALL/include -DGMP_LIBRARIES=$INSTALL/lib/libgmp.a -DMPFR_INCLUDE_DIR=$INSTALL/include -DMPFR_LIBRARIES=$INSTALL/lib/libmpfr.a >/dev/null
 cmake --build cgal-build --target install >/dev/null; touch $INSTALL/.cgal; fi
# ── EXPAT ──────────────────────────────────────
if [ ! -f $INSTALL/.expat ]; then step expat
 cd $DL; [ -d expat-2.5.0 ] || curl -fsSL https://github.com/libexpat/libexpat/releases/download/R_2_5_0/expat-2.5.0.tar.xz | tar xJ
 emcmake cmake -S expat-2.5.0 -B expat-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DEXPAT_BUILD_TOOLS=OFF -DEXPAT_BUILD_EXAMPLES=OFF -DEXPAT_BUILD_TESTS=OFF -DEXPAT_SHARED_LIBS=OFF "-DCMAKE_C_FLAGS=$XCC" >/dev/null
 emmake cmake --build expat-build --target install >/dev/null; touch $INSTALL/.expat; fi
# ── NLopt 2.5.0 (Bambu) ────────────────────────
if [ ! -f $INSTALL/.nlopt ]; then step nlopt
 cd $DL; [ -d nlopt ] || git clone -q --depth 1 --branch v2.5.0 https://github.com/stevengj/nlopt.git
 emcmake cmake -S nlopt -B nlopt-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DNLOPT_CXX=ON -DNLOPT_PYTHON=OFF -DNLOPT_GUILE=OFF -DNLOPT_MATLAB=OFF -DNLOPT_OCTAVE=OFF -DNLOPT_SWIG=OFF -DBUILD_SHARED_LIBS=OFF "-DCMAKE_C_FLAGS=$XCC" "-DCMAKE_CXX_FLAGS=$XC" >/dev/null
 emmake cmake --build nlopt-build --target install >/dev/null; touch $INSTALL/.nlopt; fi
# ── cereal 1.3.0 ───────────────────────────────
if [ ! -f $INSTALL/.cereal ]; then step cereal
 cd $DL; [ -d cereal ] || git clone -q --depth 1 --branch v1.3.0 https://github.com/USCiLab/cereal.git
 cmake -S cereal -B cereal-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DJUST_INSTALL_CEREAL=ON -DSKIP_PERFORMANCE_COMPARISON=ON -DBUILD_SANDBOX=OFF -DBUILD_DOC=OFF >/dev/null
 cmake --build cereal-build --target install >/dev/null; touch $INSTALL/.cereal; fi
# ── libnoise (bambulab) ────────────────────────
if [ ! -f $INSTALL/.noise ]; then step libnoise
 cd $DL; [ -d libnoise ] || git clone -q --depth 1 --branch v1.0.0 https://github.com/bambulab/libnoise.git
 emcmake cmake -S libnoise -B noise-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DCMAKE_BUILD_TYPE=Release -DBUILD_SHARED_LIBS=OFF "-DCMAKE_CXX_FLAGS=$XC" >/dev/null
 emmake cmake --build noise-build --target install >/dev/null; touch $INSTALL/.noise; fi
# ── zlib / libpng (kaynaktan) ──────────────────
if [ ! -f $INSTALL/.zpng ]; then step zlib-png
 cd $DL; [ -d zlib ] || git clone -q --depth 1 --branch v1.3.1 https://github.com/madler/zlib.git
 (cd zlib && CFLAGS="-O2 $XCC" emconfigure ./configure --static --prefix=$INSTALL >/dev/null && emmake make -j$J libz.a >/dev/null && make install >/dev/null)
 [ -d libpng ] || git clone -q --depth 1 --branch v1.6.43 https://github.com/pnggroup/libpng.git
 emcmake cmake -S libpng -B png-build -G Ninja -DCMAKE_INSTALL_PREFIX=$INSTALL -DCMAKE_BUILD_TYPE=Release -DPNG_SHARED=OFF -DPNG_TESTS=OFF -DPNG_TOOLS=OFF \
   -DZLIB_INCLUDE_DIR=$INSTALL/include -DZLIB_LIBRARY=$INSTALL/lib/libz.a "-DCMAKE_C_FLAGS=$XCC" >/dev/null
 emmake cmake --build png-build --target install >/dev/null
 touch $INSTALL/.zpng; fi
step ALLDONE
