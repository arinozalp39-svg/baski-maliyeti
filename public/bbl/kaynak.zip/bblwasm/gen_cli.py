#!/usr/bin/env python3
"""Bambu Studio CLI -> WASM 'CLI-lite' kaynak üretici.
PartPlate.cpp/.hpp ve BambuStudio.cpp'yi kopyalar; OpenGL/wx çizim fonksiyonlarının gövdelerini boşaltır."""
import re, sys, pathlib
SRC = pathlib.Path('/opt/wasmtc/bsrc/src')
OUT = pathlib.Path('/opt/wasmtc/bblwasm/cli')
STUB = OUT/'stubinc/slic3r/GUI'

def find_body(text, start):
    i = text.index('{', start); d = 0
    for j in range(i, len(text)):
        c = text[j]
        if c == '{': d += 1
        elif c == '}':
            d -= 1
            if d == 0: return i, j+1
    raise ValueError('unbalanced')

def comment_spans(text):
    spans = []
    for m in re.finditer(r'/\*.*?\*/|//[^\n]*', text, re.S):
        spans.append((m.start(), m.end()))
    return spans

def in_spans(pos, spans):
    import bisect
    i = bisect.bisect_right([a for a, b in spans], pos) - 1
    return i >= 0 and spans[i][0] <= pos < spans[i][1]

def blank_functions(text, cls_names, name_re, extra_exact=()):
    spans = comment_spans(text)
    # PartPlate::foo(...) / PartPlateList::foo(...) tanımlarını bul
    pat = re.compile(r'^([^\n;{}]*?)\b(' + '|'.join(cls_names) + r')::(~?\w+)\s*\(', re.M)
    out = []; pos = 0; n = 0
    for m in pat.finditer(text):
        if m.start() < pos: continue
        if in_spans(m.start(2), spans): continue
        name = m.group(3)
        if not (re.search(name_re, name) or name in extra_exact): continue
        # imza sonu: ')' sonrası '{' (const/override vs olabilir) ve arada ';' olmamalı
        par = 0; k = m.end()-1
        for k in range(m.end()-1, len(text)):
            if text[k] == '(': par += 1
            elif text[k] == ')':
                par -= 1
                if par == 0: break
        rest = text[k+1:k+200]
        mm = re.match(r'\s*(const)?\s*(override)?\s*(noexcept)?\s*\{', rest)
        if not mm: continue
        b0, b1 = find_body(text, k+1)
        ret = m.group(1).strip()
        body = '{}' if (ret.startswith('void') or ret == '' or name.startswith('~')) else '{ return {}; }'
        if '&' in ret and not ret.startswith('void'):
            body = '{ static std::remove_reference_t<' + ret.replace('static','').replace('&','').strip() + '> _s; return _s; }'
        out.append(text[pos:b0]); out.append(body + ' /* WASM: çizim kodu kaldırıldı */'); pos = b1; n += 1
    out.append(text[pos:])
    return ''.join(out), n

RENDER_RE = r'render|texture|Texture|calc_vertex|calc_triangles|calc_gridlines|calc_exclude_triangles|picking|opengl|tooltip|generate_icon|release_icon|load_render_colors|update_render_colors|draw|on_mouse'

def all_defs(text, cls_names):
    pat = re.compile(r'^([^\n;{}]*?)\b(' + '|'.join(cls_names) + r')::(~?\w+)\s*\(', re.M)
    defs = {}
    for m in pat.finditer(text):
        par = 0
        for k in range(m.end()-1, len(text)):
            if text[k] == '(': par += 1
            elif text[k] == ')':
                par -= 1
                if par == 0: break
        if not re.match(r'\s*(const)?\s*(override)?\s*(noexcept)?\s*[:{]', text[k+1:k+200]): continue
        try: b0, b1 = find_body(text, k+1)
        except Exception: continue
        defs.setdefault(m.group(3), []).append(text[m.start():b1])
    return defs

def reachable(defs, roots):
    names = set(defs); seen = set(); todo = [r for r in roots if r in names]
    while todo:
        n = todo.pop()
        if n in seen: continue
        seen.add(n)
        for body in defs[n]:
            for w in set(re.findall(r'\b([A-Za-z_]\w*)\s*\(', body)):
                if w in names and w not in seen: todo.append(w)
    return seen

if __name__ == '__main__':
    STUB.mkdir(parents=True, exist_ok=True)
    t = (SRC/'slic3r/GUI/PartPlate.cpp').read_text(errors='replace')
    cli = (SRC/'BambuStudio.cpp').read_text(errors='replace')
    defs = all_defs(t, ['PartPlate', 'PartPlateList'])
    # CLI'nin çağırdığı metotlar + kurucu/yıkıcılar kökler
    used = set(re.findall(r'(?:\.|->)\s*(\w+)\s*\(', cli)) | {'PartPlate', 'PartPlateList', '~PartPlate', '~PartPlateList', 'init'}
    reach = reachable(defs, [n for n in defs if n in used])
    unreach = set(defs) - reach
    (OUT/'partplate_reach.txt').write_text('REACHABLE:\n' + '\n'.join(sorted(reach)) + '\n\nBLANKED (unreachable):\n' + '\n'.join(sorted(unreach)))
    t, n = blank_functions(t, ['PartPlate', 'PartPlateList'], RENDER_RE, extra_exact=unreach | set(sys.argv[1:]))
    (STUB/'PartPlate.cpp').write_text(t)
    h = (SRC/'slic3r/GUI/PartPlate.hpp').read_text(errors='replace')
    (STUB/'PartPlate.hpp').write_text(h)
    c = (SRC/'BambuStudio.cpp').read_text(errors='replace')
    c = c.replace('boost::filesystem::path path_to_binary = boost::dll::program_location();',
                  'boost::filesystem::path path_to_binary("/bbl/bin/bambu-studio"); // WASM: sanal dosya sistemi')
    assert '/bbl/bin/bambu-studio' in c
    (OUT/'bbl_cli.cpp').write_text(c)
    (OUT/'BambuStudio.hpp').write_text((SRC/'BambuStudio.hpp').read_text(errors='replace'))
    print('PartPlate: blanked', n, 'functions')
