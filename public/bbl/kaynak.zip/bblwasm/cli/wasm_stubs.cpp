// WASM: tarayıcıda bulunmayan kütüphane fonksiyonları için boş karşılıklar.
#include <string>
#include <pthread.h>
namespace Slic3r {
struct TexturedMesh;
// Assimp (dokulu model içe aktarma) yok: dilimlemeyi etkilemez.
bool load_assimp_textured_model(const std::string&, TexturedMesh&, std::string* error_message)
{ if (error_message) *error_message = "not supported in browser"; return false; }
}
extern "C" int pthread_setname_np(pthread_t, const char*) { return 0; }
