#pragma once
// WASM CLI-lite: Bambu Studio GUI sınıflarının yerine geçen asgari tanımlar.
// Sadece çizim (OpenGL/wx) tarafı boşaltılmıştır; dilimleme mantığı değişmez.
#include <memory>
#include <string>
#include <vector>
#include <array>
#include <map>
#include <functional>
#include <cstdio>
#include "libslic3r/libslic3r.h"
#include "libslic3r/Point.hpp"
#include "libslic3r/BoundingBox.hpp"
#include "libslic3r/PrintConfig.hpp"
#include "libslic3r/GCode/ThumbnailData.hpp"
#include "libslic3r/PresetBundle.hpp"
#include "libslic3r/AppConfig.hpp"
#include "libslic3r/BuildVolume.hpp"
#include "nlohmann/json.hpp"
#include <cstring>
#include <boost/nowide/fstream.hpp>

class wxString {
public:
    std::string s;
    wxString() {}
    wxString(const char* c) : s(c ? c : "") {}
    wxString(const std::string& c) : s(c) {}
    std::string ToStdString() const { return s; }
    struct U8 { std::string s; const char* data() const { return s.c_str(); } operator std::string() const { return s; } };
    U8 utf8_str() const { return U8{s}; }
    std::string utf8_string() const { return s; }
    const char* c_str() const { return s.c_str(); }
    bool empty() const { return s.empty(); }
    bool IsEmpty() const { return s.empty(); }
    wxString& operator+=(const wxString& o) { s += o.s; return *this; }
    wxString& operator+=(const char* o) { s += o; return *this; }
    friend wxString operator+(const wxString& a, const wxString& b) { return wxString(a.s + b.s); }
    static const char* fmt_arg(const wxString& v) { return v.s.c_str(); }
    static const char* fmt_arg(const std::string& v) { return v.c_str(); }
    static const char* fmt_arg(const char* v) { return v; }
    template<class T> static T fmt_arg(T v) { return v; }
    template<class... A> static wxString Format(const wxString& f, A... a) {
        char buf[4096]; std::snprintf(buf, sizeof buf, f.s.c_str(), fmt_arg(a)...); return wxString(buf); }
    static wxString FromUTF8(const std::string& c) { return wxString(c); }
    static wxString FromUTF8(const char* c) { return wxString(c); }
};
typedef unsigned int GLuint;
typedef int GLint;
typedef unsigned int GLenum;
typedef float GLfloat;
class GLUquadric {};
inline void glDeleteBuffers(int, const unsigned int*) {}
#define glsafe(x) x
inline void glDeleteTextures(int, const unsigned int*) {}
class wxImage {
public:
    bool LoadFile(const wxString&, int) { return false; }
    wxImage Mirror(bool) const { return *this; }
    int GetWidth() const { return 0; } int GetHeight() const { return 0; }
    unsigned char* GetData() const { return nullptr; } unsigned char* GetAlpha() const { return nullptr; }
    bool HasAlpha() const { return false; }
};
#define wxBITMAP_TYPE_PNG 15
#define wxID_YES 5103
#define wxID_NO 5104
#include <boost/format.hpp>
#define _L(s) wxString(s)
#define _u8L(s) std::string(s)
#define L(s) (s)

namespace Slic3r {
struct HelioPlateResult {};
class GLShaderProgram {};
class GLVolume { public: int geometry_id = 0; bool printable = true; template<class... A> void set_render_color(A&&...) {} template<class... A> void set_color(A&&...) {} BoundingBoxf3 bounding_box() const { return {}; } BoundingBoxf3 transformed_convex_hull_bounding_box() const { return {}; } };
class GLVolumeCollection { public: std::vector<GLVolume*> volumes; void clear() {} template<class... A> void load_object_volume(A&&...) { static GLVolume v; volumes.push_back(&v); } };
namespace GUI {
class GLModel { public: void reset() {} bool is_initialized() const { return false; } template<class... A> bool init_from(A&&...) { return false; } template<class... A> bool init_model_from_lines(A&&...) { return false; } template<class... A> bool init_model_from_poly(A&&...) { return false; } template<class... A> void set_color(A&&...) {} void render() const {} };
class GLTexture { public: void reset() {} unsigned int get_id() const { return 0; } int get_width() const { return 0; } int get_height() const { return 0; } };
class Bed3D {
public:
    std::string get_model_filename() const { return {}; }
    BoundingBoxf3 get_cur_bed_model_box() const { return {}; }
    BoundingBoxf3 get_bounding_box(bool) const { return {}; }
};
struct CameraObj {
    double get_distance() const { return 0; }
    void look_at(const Vec3d&, const Vec3d&, const Vec3d&) {}
    void select_view(const std::string&) {}
};
struct PrinterModelStub { std::string use_rect_grid; };
class Sidebar { public: std::vector<BedType> get_cur_combox_bed_types() { return {}; } };
class ObjectDataViewModel { public: template<class... A> void SetCurSelectedPlateFullName(A&&...) {} };
class Plater {
public:
    static bool has_illegal_filename_characters(const std::string& name) {
        const char* illegal_characters = "<>:/\\|?*\"";
        for (size_t i = 0; i < std::strlen(illegal_characters); i++)
            if (name.find_first_of(illegal_characters[i]) != std::string::npos) return true;
        std::array<std::string, 5> escape_characters = {"&lt;", "&gt;", "&amp;", "&quot;", "&apos;"};
        for (auto escape : escape_characters) if (name.find(escape) != std::string::npos) return true;
        return false;
    }
    static void show_illegal_characters_warning(Plater*) {}
    int get_right_icon_offset_bed(int) { return 0; }
    bool is_gcode_3mf() const { return false; }
    void mark_plate_toolbar_image_dirty() {}
    void take_snapshot(const std::string&) {}
    std::vector<int> get_global_filament_map() { return {}; }
    void set_global_filament_map(const std::vector<int>&) {}
    const PrinterModelStub* get_curr_printer_model() { return nullptr; }
    void set_bed_position(const Vec2d&) {}
    CameraObj& get_camera() { static CameraObj c; return c; }
    Bed3D& get_bed() { static Bed3D b; return b; }
    void reset_gcode_toolpaths() {}
    DynamicPrintConfig* config() { static DynamicPrintConfig c; return &c; }
    std::map<std::string, std::string> get_bed_texture_maps() { return {}; }
    Sidebar& sidebar() { static Sidebar s; return s; }
};
class ObjectList { public: ObjectDataViewModel* GetModel() { return nullptr; } void reload_all_plates(bool = false) {} void update_selections() {} template<class T> void on_plate_added(T*) {} };
class Tab {};
class TabPrintPlate : public Tab { public: int show_spiral_mode_settings_dialog(bool) { return 0; } };
class GUI_App {
public:
    PresetBundle* preset_bundle { nullptr };
    AppConfig*    app_config { nullptr };
    Tab*          plate_tab { nullptr };
    Plater*       plater() { return nullptr; }
    ObjectList*   obj_list() { return nullptr; }
    PrintSequence global_print_sequence() const { return PrintSequence::ByLayer; }
};
inline GUI_App& wxGetApp() { static GUI_App app; return app; }
template<class A, class B> inline void wxQueueEvent(A*, B*) {}
template<typename... Args> inline wxString format(const wxString& fmt, Args&&... args) {
    boost::format f(fmt.s); ((f % args), ...); return wxString(f.str()); }
class BackgroundSlicingProcess;
class Plater;
struct Camera {
    enum EType : unsigned char { Ortho, Perspective, Num_types };
    enum class ViewAngleType : unsigned char { Iso = 0, Top_Front, Left, Right, Top, Bottom, Front, Rear, Top_Plate, Count_ViewAngleType };
};
class OpenGLManager {
public:
    enum class EFramebufferType : unsigned char { Unknown, Arb, Ext };
    std::shared_ptr<GLShaderProgram> get_shader(const std::string&) { return nullptr; }
    void bind_shader(const std::shared_ptr<GLShaderProgram>&) {}
    void unbind_shader() {}
    void set_legacy_framebuffer_enabled(bool) {}
    void bind_vao() {}
    void unbind_vao() {}
    bool init_gl(bool = false) { return false; }
    static EFramebufferType get_framebuffers_type() { return EFramebufferType::Unknown; }
    static std::string framebuffer_type_to_string(EFramebufferType) { return "none"; }
};
class GLCanvas3D {
public:
    template<class... A> static void render_thumbnail_framebuffer(A&&...) {}
};
class BitmapCache {
public:
    static bool parse_color4(const std::string& scolor, unsigned char* rgba_out);
};
std::vector<int> get_min_flush_volumes(const DynamicPrintConfig &full_config, size_t nozzle_id);
}
}
struct Label { static void initSysFont() {} };
using namespace std;
