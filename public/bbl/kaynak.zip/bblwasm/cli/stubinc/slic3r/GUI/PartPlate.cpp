#include <cstddef>
#include <algorithm>
#include <numeric>
#include <vector>
#include <string>
#include <future>
#include <GL/glew.h>
#include <boost/algorithm/string.hpp>
#include <boost/optional.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/log/trivial.hpp>
#include <boost/nowide/convert.hpp>
#include <boost/nowide/cstdio.hpp>
#include <boost/algorithm/string/predicate.hpp>

#include "libslic3r/libslic3r.h"
#include "libslic3r/Polygon.hpp"
#include "libslic3r/ClipperUtils.hpp"
#include "libslic3r/BoundingBox.hpp"
#include "libslic3r/Geometry.hpp"
#include "libslic3r/Tesselate.hpp"
#include "libslic3r/GCode/ThumbnailData.hpp"
#include "libslic3r/Utils.hpp"
#include "libslic3r/Print.hpp"
#include "slic3r/GUI/OpenGLManager.hpp"

#include "I18N.hpp"
#include "GUI_App.hpp"
#include "DeviceCore/DevConfigUtil.h"
#include "libslic3r/FilamentMixer.hpp"
#include "libslic3r/AppConfig.hpp"
#include "libslic3r/PresetBundle.hpp"
#include "BackgroundSlicingProcess.hpp"
#include "Widgets/Label.hpp"
#include "3DBed.hpp"
#include "PartPlate.hpp"
#include "Camera.hpp"
#include "GUI_Colors.hpp"
#include "GUI_ObjectList.hpp"
#include "Tab.hpp"
#include "format.hpp"
#include "../Utils/HelioDragon.hpp"
#include <imgui/imgui_internal.h>
#include <wx/dcgraph.h>
using boost::optional;
namespace fs = boost::filesystem;

static const float GROUND_Z = -0.03f;
static const float GRABBER_X_FACTOR = 0.20f;
static const float GRABBER_Y_FACTOR = 0.03f;
static const float GRABBER_Z_VALUE = 0.5f;
static unsigned int GLOBAL_PLATE_INDEX = 0;

static const double LOGICAL_PART_PLATE_GAP = 1. / 5.;
static const int PARTPLATE_ICON_SIZE = 16;
static const int PARTPLATE_EDIT_PLATE_NAME_ICON_SIZE = 12;
static const int PARTPLATE_PLATE_NAME_FIX_HEIGHT_SIZE = 20;
static const int PARTPLATE_ICON_GAP_TOP = 3;
static const int PARTPLATE_NAME_EDIT_ICON_GAP_LEFT = 3;
static const int PARTPLATE_ICON_GAP_LEFT = 3;
static const int PARTPLATE_ICON_GAP_Y = 5;
static const int PARTPLATE_TEXT_OFFSET_X1 = 3;
static const int PARTPLATE_TEXT_OFFSET_X2 = 1;
static const int PARTPLATE_TEXT_OFFSET_Y = 1;
static const int PARTPLATE_PLATENAME_OFFSET_Y  = 10;

const float WIPE_TOWER_DEFAULT_X_POS = 165.;
const float WIPE_TOWER_DEFAULT_Y_POS = 250.;  // Max y

const float N9_WIPE_TOWER_DEFAULT_Y_POS = 160.;

const float I3_WIPE_TOWER_DEFAULT_X_POS = 0.;
const float I3_WIPE_TOWER_DEFAULT_Y_POS = 250.; // Max y

std::array<unsigned char, 4>  PlateTextureForeground = {0x0, 0xae, 0x42, 0xff};

namespace Slic3r {
namespace GUI {

std::array<float, 4> PartPlate::SELECT_COLOR		= { 0.2666f, 0.2784f, 0.2784f, 1.0f }; //{ 0.4196f, 0.4235f, 0.4235f, 1.0f };
std::array<float, 4> PartPlate::UNSELECT_COLOR		= { 0.82f, 0.82f, 0.82f, 1.0f };
std::array<float, 4> PartPlate::UNSELECT_DARK_COLOR		= { 0.384f, 0.384f, 0.412f, 1.0f };
std::array<float, 4> PartPlate::DEFAULT_COLOR		= { 0.5f, 0.5f, 0.5f, 1.0f };
std::array<float, 4> PartPlate::LINE_TOP_COLOR		= { 0.89f, 0.89f, 0.89f, 1.0f };
std::array<float, 4> PartPlate::LINE_TOP_DARK_COLOR		= { 0.431f, 0.431f, 0.463f, 1.0f };
std::array<float, 4> PartPlate::LINE_TOP_SEL_COLOR  = { 0.5294f, 0.5451, 0.5333f, 1.0f};
std::array<float, 4> PartPlate::LINE_TOP_SEL_DARK_COLOR = { 0.298f, 0.298f, 0.3333f, 1.0f};
std::array<float, 4> PartPlate::LINE_BOTTOM_COLOR	= { 0.8f, 0.8f, 0.8f, 0.4f };
std::array<float, 4> PartPlate::HEIGHT_LIMIT_TOP_COLOR		= { 0.6f, 0.6f, 1.0f, 1.0f };
std::array<float, 4> PartPlate::HEIGHT_LIMIT_BOTTOM_COLOR	= { 0.4f, 0.4f, 1.0f, 1.0f };


void PartPlate::update_render_colors()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::load_render_colors()
{} /* WASM: çizim kodu kaldırıldı */


PartPlate::PartPlate()
	: ObjectBase(-1), m_plater(nullptr), m_model(nullptr), m_quadric(nullptr)
{
	assert(this->id().invalid());
	init();
}

PartPlate::PartPlate(PartPlateList *partplate_list, Vec3d origin, int width, int depth, int height, Plater* platerObj, Model* modelObj, bool printable, PrinterTechnology tech)
	:m_partplate_list(partplate_list), m_plater(platerObj), m_model(modelObj), printer_technology(tech), m_origin(origin), m_width(width), m_depth(depth), m_height(height),  m_printable(printable)
{
	init();
}

PartPlate::~PartPlate()
{
	clear();
	//if (m_quadric != nullptr)
	//	::gluDeleteQuadric(m_quadric);
	release_opengl_resource();

	//boost::nowide::remove(m_tmp_gcode_path.c_str());
}

void PartPlate::init()
{
	m_locked = false;
	m_ready_for_slice = true;
	m_slice_result_valid = false;
	m_slice_percent = 0.0f;
	m_hover_id = -1;
	m_selected = false;
	//m_quadric = ::gluNewQuadric();
	//if (m_quadric != nullptr)
	//	::gluQuadricDrawStyle(m_quadric, GLU_FILL);

	m_print_index = -1;
	m_print = nullptr;
	m_config.option<ConfigOptionEnum<FilamentMapMode>>("filament_map_mode", true)->value = FilamentMapMode::fmmAutoForFlush;
}

BedType PartPlate::get_bed_type(bool load_from_project) const
{
	std::string bed_type_key = "curr_bed_type";

	if (m_config.has(bed_type_key)) {
		BedType bed_type = m_config.opt_enum<BedType>(bed_type_key);
		return bed_type;
	}

	if (!load_from_project || !m_plater || !wxGetApp().preset_bundle)
		return btDefault;

	DynamicConfig& proj_cfg = wxGetApp().preset_bundle->project_config;
	if (proj_cfg.has(bed_type_key))
		return proj_cfg.opt_enum<BedType>(bed_type_key);
	return btDefault;
}

void PartPlate::set_bed_type(BedType bed_type)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::reset_bed_type()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_print_seq(PrintSequence print_seq)
{} /* WASM: çizim kodu kaldırıldı */

PrintSequence PartPlate::get_print_seq() const
{
    std::string print_seq_key = "print_sequence";

    if (m_config.has(print_seq_key)) {
        PrintSequence print_seq = m_config.opt_enum<PrintSequence>(print_seq_key);
        return print_seq;
    }

    return PrintSequence::ByDefault;
}

PrintSequence PartPlate::get_real_print_seq(bool* plate_same_as_global) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::vector<int> PartPlate::get_real_filament_maps(const DynamicConfig& g_config, bool* use_global_param) const
{
	auto maps = get_filament_maps();
	if (!maps.empty()) {
		if (use_global_param) { *use_global_param = false; }
		return maps;
	}
	auto g_maps = g_config.option<ConfigOptionInts>("filament_map")->values;
	if (use_global_param) { *use_global_param = true; }
	return g_maps;
}

FilamentMapMode PartPlate::get_real_filament_map_mode(const DynamicConfig& g_config, bool* use_global_param) const
{
	auto mode = get_filament_map_mode();
	if (FilamentMapMode::fmmDefault != mode) {
		if (use_global_param) { *use_global_param = false; };
		return mode;
	}

	auto g_mode = g_config.option<ConfigOptionEnum<FilamentMapMode>>("filament_map_mode")->value;
	if (use_global_param) { *use_global_param = true; }
	return g_mode;
}

std::vector<int> PartPlate::get_real_filament_volume_maps(const DynamicConfig& g_config, bool* use_global_param) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::has_spiral_mode_config() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::get_spiral_vase_mode() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_spiral_vase_mode(bool spiral_mode, bool as_global)
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlate::valid_instance(int obj_id, int instance_id)
{
	if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
	{
		ModelObject* object = m_model->objects[obj_id];
		if ((instance_id >= 0) && (instance_id < object->instances.size()))
			return true;
	}

	return false;
}

void PartPlate::calc_bounding_boxes() const {
	BoundingBoxf3* bounding_box = const_cast<BoundingBoxf3*>(&m_bounding_box);
	*bounding_box = BoundingBoxf3();
	for (const Vec2d& p : m_shape) {
		bounding_box->merge({ p(0), p(1), 0.0 });
	}

	BoundingBoxf3* extended_bounding_box = const_cast<BoundingBoxf3*>(&m_extended_bounding_box);
	*extended_bounding_box = m_bounding_box;

	double half_x = bounding_box->size().x() * GRABBER_X_FACTOR;
	double half_y = bounding_box->size().y() * 1.0f * GRABBER_Y_FACTOR;
	double half_z = GRABBER_Z_VALUE;
	Vec3d center(bounding_box->center().x(), bounding_box->min(1) -half_y, GROUND_Z);
	m_grabber_box.min = Vec3d(center.x() - half_x, center.y() - half_y, center.z() - half_z);
	m_grabber_box.max = Vec3d(center.x() + half_x, center.y() + half_y, center.z() + half_z);
	m_grabber_box.defined = true;
	extended_bounding_box->merge(m_grabber_box);

    //calc exclude area bounding box
    m_exclude_bounding_box.clear();
    BoundingBoxf3 exclude_bb;
    for (int index = 0; index < m_exclude_area.size(); index ++) {
		const Vec2d& p = m_exclude_area[index];

		if (index % 4 == 0)
			exclude_bb = BoundingBoxf3();

		exclude_bb.merge({ p(0), p(1), 0.0 });

		if (index % 4 == 3)
		{
			exclude_bb.max(2) = m_depth;
			exclude_bb.min(2) = GROUND_Z;
			m_exclude_bounding_box.emplace_back(exclude_bb);
		}
	}
}

void PartPlate::calc_height_limit() {
	Lines3 bottom_h_lines, top_lines, top_h_lines, common_lines;
	int shape_count = m_shape.size();
	float first_z = 0.02f;
	for (int i = 0; i < shape_count; i++) {
		auto &cur_p = m_shape[i];
		Vec3crd p1(scale_(cur_p.x()), scale_(cur_p.y()), scale_(first_z));
		Vec3crd p2(scale_(cur_p.x()), scale_(cur_p.y()), scale_(m_height_to_rod));
		Vec3crd p3(scale_(cur_p.x()), scale_(cur_p.y()), scale_(m_height_to_lid));

		common_lines.emplace_back(p1, p2);
		top_lines.emplace_back(p2, p3);

		Vec2d next_p;
		if (i < (shape_count - 1)) {
			next_p = m_shape[i+1];

		}
		else {
			next_p = m_shape[0];
		}
		Vec3crd p4(scale_(cur_p.x()), scale_(cur_p.y()), scale_(m_height_to_rod));
		Vec3crd p5(scale_(next_p.x()), scale_(next_p.y()), scale_(m_height_to_rod));
		bottom_h_lines.emplace_back(p4, p5);

		Vec3crd p6(scale_(cur_p.x()), scale_(cur_p.y()), scale_(m_height_to_lid));
		Vec3crd p7(scale_(next_p.x()), scale_(next_p.y()), scale_(m_height_to_lid));
		top_h_lines.emplace_back(p6, p7);
	}
	//std::copy(bottom_lines.begin(), bottom_lines.end(), std::back_inserter(bottom_h_lines));
	std::copy(top_lines.begin(), top_lines.end(), std::back_inserter(top_h_lines));
    m_height_limit_common.reset();
    if (!m_height_limit_common.init_model_from_lines(common_lines))
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << "Unable to create height limit bottom lines\n";
    m_height_limit_bottom.reset();
    if (!m_height_limit_bottom.init_model_from_lines(bottom_h_lines))
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << "Unable to create height limit bottom lines\n";
    m_height_limit_top.reset();
    if (!m_height_limit_top.init_model_from_lines(top_h_lines))
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << "Unable to create height limit top lines\n";
}

int PartPlate::get_right_icon_offset_bed(int i)
{
    if (&wxGetApp() && wxGetApp().plater()) {
        auto offset = wxGetApp().plater()->get_right_icon_offset_bed(i);
        if (i > 0 && offset == 0) {
            return 0;
        }
        return offset == 0 ? PARTPLATE_ICON_GAP_LEFT : offset;
    } else {
        return PARTPLATE_ICON_GAP_LEFT;
    }
}

void PartPlate::calc_vertex_for_plate_name(GLTexture &texture, GLModel &gl_model)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::calc_vertex_for_plate_name_edit_icon(GLTexture *texture, int index, GLModel &gl_model)
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlate::calc_bed_3d_boundingbox(BoundingBoxf3 &box_in_plate_origin) {
    if (m_partplate_list && m_partplate_list->m_bed3d && !m_partplate_list->m_bed3d->get_model_filename().empty()) {
        auto cur_bed = m_partplate_list->m_bed3d;
        auto cur_box = cur_bed->get_cur_bed_model_box();
        if (cur_box.size().x() > 1.0f) {
            Vec3d min_ = cur_box.min - m_origin;
            Vec3d max_ = cur_box.max - m_origin;
            cur_box.reset();
            cur_box.merge(min_);
            cur_box.merge(max_);
            box_in_plate_origin = cur_box;
            return true;
        }
    }
	return false;
}

void PartPlate::render_logo_texture(GLTexture &logo_texture, GLModel &logo_buffer, bool bottom)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_logo(bool bottom, bool render_cali)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_height_limit(PartPlate::HeightLimitMode mode)
{} /* WASM: çizim kodu kaldırıldı */


void PartPlate::render_icon_texture(GLModel &icon, GLTexture &texture)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::show_tooltip(const std::string tooltip)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_plate_name_texture()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_icons(bool bottom, bool only_body, int hover_id, bool render_name_edit_icon)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_plate_name_icon_and_texture(bool only_body, int hover_id)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_numbers(bool bottom)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_label(GLCanvas3D& canvas) const {} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_grabber(const float* render_color, bool use_lighting) const
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_face(float x_size, float y_size) const
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_arrows(const float* render_color, bool use_lighting) const
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::render_left_arrow(const float* render_color, bool use_lighting) const
{} /* WASM: çizim kodu kaldırıldı */
void PartPlate::render_right_arrow(const float* render_color, bool use_lighting) const
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::on_render_for_picking() {} /* WASM: çizim kodu kaldırıldı */

std::array<float, 4> PartPlate::picking_color_component(int idx) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlate::release_opengl_resource()
{} /* WASM: çizim kodu kaldırıldı */

std::vector<int> PartPlate::get_extruders(bool conside_custom_gcode) const
{
	std::vector<int> plate_extruders;
    if (check_objects_empty_and_gcode3mf(plate_extruders)) {
        return plate_extruders;
    }
	// if 3mf file
	const DynamicPrintConfig& glb_config = wxGetApp().preset_bundle->prints.get_edited_preset().config;
	int glb_support_intf_extr = glb_config.opt_int("support_interface_filament");
	int glb_support_extr = glb_config.opt_int("support_filament");
	int glb_wall_extr = glb_config.opt_int("wall_filament");
	int glb_sparse_infill_extr = glb_config.opt_int("sparse_infill_filament");
	int glb_solid_infill_extr = glb_config.opt_int("solid_infill_filament");
	bool glb_support = glb_config.opt_bool("enable_support");
    glb_support |= glb_config.opt_int("raft_layers") > 0;

	for (int obj_idx = 0; obj_idx < m_model->objects.size(); obj_idx++) {
		if (!contain_instance_totally(obj_idx, 0))
			continue;

		ModelObject* mo = m_model->objects[obj_idx];
		for (ModelVolume* mv : mo->volumes) {
			std::vector<int> volume_extruders = mv->get_extruders();
			plate_extruders.insert(plate_extruders.end(), volume_extruders.begin(), volume_extruders.end());
		}

		// layer range
        for (auto layer_range : mo->layer_config_ranges) {
            if (layer_range.second.has("extruder")) {
                if (auto id = layer_range.second.option("extruder")->getInt(); id > 0)
					plate_extruders.push_back(id);
			}
		}

		// filaments for features
        for (ModelVolume *mv : mo->volumes) { // go throught all volumes
            ModelConfigObject &mv_config = mv->config;
            int                 obj_wall_extr = 0, vol_wall_extr = 0;
            const ConfigOption *wall_opt = mo->config.option("wall_filament");
            if (wall_opt != nullptr) obj_wall_extr = wall_opt->getInt();
            const ConfigOption *vol_wall_opt = mv_config.option("wall_filament");
            if (vol_wall_opt != nullptr) vol_wall_extr = vol_wall_opt->getInt();
            if (vol_wall_extr != 0)
                plate_extruders.push_back(vol_wall_extr);
            else if (obj_wall_extr != 0)
                plate_extruders.push_back(obj_wall_extr);
            else if (glb_wall_extr != 0)
                plate_extruders.push_back(glb_wall_extr);

            int                 obj_sparse_infill_extr = 0, vol_spare_infill_extr = 0;
            const ConfigOption *sparse_infill_opt = mo->config.option("sparse_infill_filament");
            if (sparse_infill_opt != nullptr) obj_sparse_infill_extr = sparse_infill_opt->getInt();
            const ConfigOption *vol_infill_opt = mv_config.option("sparse_infill_filament");
            if (vol_infill_opt != nullptr) vol_spare_infill_extr = vol_infill_opt->getInt();
            if (vol_spare_infill_extr != 0)
                plate_extruders.push_back(vol_spare_infill_extr);
            else if (obj_sparse_infill_extr != 0)
                plate_extruders.push_back(obj_sparse_infill_extr);
            else if (glb_sparse_infill_extr != 0)
                plate_extruders.push_back(glb_sparse_infill_extr);

            int                 obj_solid_infill_extr = 0, vol_solid_infill_extr = 0;
            const ConfigOption *solid_infill_opt = mo->config.option("solid_infill_filament");
            if (solid_infill_opt != nullptr) obj_solid_infill_extr = solid_infill_opt->getInt();
            const ConfigOption *vol_solid_infill_opt = mv_config.option("solid_infill_filament");
            if (vol_solid_infill_opt != nullptr) vol_solid_infill_extr = vol_solid_infill_opt->getInt();
            if (vol_solid_infill_extr != 0)
                plate_extruders.push_back(vol_solid_infill_extr);
            else if (obj_solid_infill_extr != 0)
                plate_extruders.push_back(obj_solid_infill_extr);
            else if (glb_solid_infill_extr != 0)
                plate_extruders.push_back(glb_solid_infill_extr);
        }

		bool obj_support = false;
		const ConfigOption* obj_support_opt = mo->config.option("enable_support");
        const ConfigOption *obj_raft_opt    = mo->config.option("raft_layers");
		if (obj_support_opt != nullptr || obj_raft_opt != nullptr) {
            if (obj_support_opt != nullptr)
				obj_support = obj_support_opt->getBool();
            if (obj_raft_opt != nullptr)
				obj_support |= obj_raft_opt->getInt() > 0;
        }
		else
			obj_support = glb_support;

		if (!obj_support)
			continue;

		int obj_support_intf_extr = 0;
		const ConfigOption* support_intf_extr_opt = mo->config.option("support_interface_filament");
		if (support_intf_extr_opt != nullptr)
			obj_support_intf_extr = support_intf_extr_opt->getInt();
		if (obj_support_intf_extr != 0)
			plate_extruders.push_back(obj_support_intf_extr);
		else if (glb_support_intf_extr != 0)
			plate_extruders.push_back(glb_support_intf_extr);

		int obj_support_extr = 0;
		const ConfigOption* support_extr_opt = mo->config.option("support_filament");
		if (support_extr_opt != nullptr)
			obj_support_extr = support_extr_opt->getInt();
		if (obj_support_extr != 0)
			plate_extruders.push_back(obj_support_extr);
		else if (glb_support_extr != 0)
			plate_extruders.push_back(glb_support_extr);
	}

	if (conside_custom_gcode) {
		//BBS
        int nums_extruders = 0;
        if (const ConfigOptionStrings *color_option = dynamic_cast<const ConfigOptionStrings *>(wxGetApp().preset_bundle->project_config.option("filament_colour"))) {
            nums_extruders = color_option->values.size();
			if (m_model->plates_custom_gcodes.find(m_plate_index) != m_model->plates_custom_gcodes.end()) {
				for (auto item : m_model->plates_custom_gcodes.at(m_plate_index).gcodes) {
					if (item.type == CustomGCode::Type::ToolChange && item.extruder <= nums_extruders)
						plate_extruders.push_back(item.extruder);
				}
			}
		}
	}

	std::sort(plate_extruders.begin(), plate_extruders.end());
	auto it_end = std::unique(plate_extruders.begin(), plate_extruders.end());
	plate_extruders.resize(std::distance(plate_extruders.begin(), it_end));

	// Expand mixed filament slots to their physical components
	auto& project_config = wxGetApp().preset_bundle->project_config;
	auto* is_mixed_opt = project_config.option<ConfigOptionBools>("filament_is_mixed");
	auto* comp_strs_opt = project_config.option<ConfigOptionStrings>("filament_mixed_components");
	if (is_mixed_opt && comp_strs_opt && has_any_mixed_filament(is_mixed_opt->values)) {
		std::vector<unsigned int> ext_0based;
		for (int e : plate_extruders)
			if (e >= 1) ext_0based.push_back((unsigned int)(e - 1));
		auto expanded = expand_mixed_filaments(ext_0based, is_mixed_opt->values, comp_strs_opt->values);
		plate_extruders.clear();
		for (unsigned int e : expanded)
			plate_extruders.push_back((int)(e + 1));
	}

	return plate_extruders;
}

std::vector<int> PartPlate::get_extruders_under_cli(bool conside_custom_gcode, DynamicPrintConfig& full_config) const
{
    std::vector<int> plate_extruders;

    // if 3mf file
    int glb_support_intf_extr = full_config.opt_int("support_interface_filament");
    int  glb_support_extr       = full_config.opt_int("support_filament");
    int  glb_wall_extr          = full_config.opt_int("wall_filament");
    int  glb_sparse_infill_extr = full_config.opt_int("sparse_infill_filament");
    int  glb_solid_infill_extr  = full_config.opt_int("solid_infill_filament");
    bool glb_support = full_config.opt_bool("enable_support");
    glb_support |= full_config.opt_int("raft_layers") > 0;

    for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
    {
        int obj_id = it->first;
        int instance_id = it->second;

        if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
        {
            ModelObject* object = m_model->objects[obj_id];
            ModelInstance* instance = object->instances[instance_id];

            if (!instance->printable)
                continue;

            for (ModelVolume* mv : object->volumes) {
                std::vector<int> volume_extruders = mv->get_extruders();
                plate_extruders.insert(plate_extruders.end(), volume_extruders.begin(), volume_extruders.end());
            }

            // layer range
            for (auto layer_range : object->layer_config_ranges) {
                if (layer_range.second.has("extruder")) {
                    if (auto id = layer_range.second.option("extruder")->getInt(); id > 0)
                        plate_extruders.push_back(id);
                }
            }

		// filaments for features
            bool enabled_SFFF_mo = object->config.option("separate_filaments_for_features") && object->config.option("separate_filaments_for_features")->getBool(),
                 mo_not_override = object->config.option("separate_filaments_for_features") == nullptr;
            for (ModelVolume *mv : object->volumes) { // go throught all volumes
                ModelConfigObject &mv_config = mv->config;
                // volume not overrided,or overrided with enabled
                bool enabled_SFFF_mv = mv_config.option("separate_filaments_for_features") && mv_config.option("separate_filaments_for_features")->getBool(),
                     mv_not_override = mv_config.option("separate_filaments_for_features") == nullptr;
                if (enabled_SFFF_mv || (mv_not_override && enabled_SFFF_mo)) {
                    int                 obj_wall_extr = 0, vol_wall_extr = 0;
                    const ConfigOption *wall_opt = object->config.option("wall_filament");
                    if (wall_opt != nullptr) obj_wall_extr = wall_opt->getInt();
                    const ConfigOption *vol_wall_opt = mv_config.option("wall_filament");
                    if (vol_wall_opt != nullptr) vol_wall_extr = vol_wall_opt->getInt();
                    if (vol_wall_extr != 0)
                        plate_extruders.push_back(vol_wall_extr);
                    else if (obj_wall_extr != 0 && (mv_not_override && enabled_SFFF_mo))
                        plate_extruders.push_back(obj_wall_extr);
                    else if (glb_wall_extr != 0 && (mv_not_override && mo_not_override && glb_sparse_infill_extr))
                        plate_extruders.push_back(glb_wall_extr);

                    int                 obj_sparse_infill_extr = 0, vol_spare_infill_extr = 0;
                    const ConfigOption *sparse_infill_opt = object->config.option("sparse_infill_filament");
                    if (sparse_infill_opt != nullptr) obj_sparse_infill_extr = sparse_infill_opt->getInt();
                    const ConfigOption *vol_infill_opt = mv_config.option("sparse_infill_filament");
                    if (vol_infill_opt != nullptr) vol_spare_infill_extr = vol_infill_opt->getInt();
                    if (vol_spare_infill_extr != 0)
                        plate_extruders.push_back(vol_spare_infill_extr);
                    else if (obj_sparse_infill_extr != 0 && (mv_not_override && enabled_SFFF_mo))
                        plate_extruders.push_back(obj_sparse_infill_extr);
                    else if (glb_sparse_infill_extr != 0 && (mv_not_override && mo_not_override && glb_sparse_infill_extr))
                        plate_extruders.push_back(glb_sparse_infill_extr);

                    int                 obj_solid_infill_extr = 0, vol_solid_infill_extr = 0;
                    const ConfigOption *solid_infill_opt = object->config.option("solid_infill_filament");
                    if (solid_infill_opt != nullptr) obj_solid_infill_extr = solid_infill_opt->getInt();
                    const ConfigOption *vol_solid_infill_opt = mv_config.option("solid_infill_filament");
                    if (vol_solid_infill_opt != nullptr) vol_solid_infill_extr = vol_solid_infill_opt->getInt();
                    if (vol_solid_infill_extr != 0)
                        plate_extruders.push_back(vol_solid_infill_extr);
                    else if (obj_solid_infill_extr != 0 && (mv_not_override && enabled_SFFF_mo))
                        plate_extruders.push_back(obj_solid_infill_extr);
                    else if (glb_solid_infill_extr != 0 && (mv_not_override && mo_not_override && glb_sparse_infill_extr))
                        plate_extruders.push_back(glb_solid_infill_extr);
                }
            }

            bool obj_support = false;
            const ConfigOption* obj_support_opt = object->config.option("enable_support");
            const ConfigOption *obj_raft_opt    = object->config.option("raft_layers");
            if (obj_support_opt != nullptr || obj_raft_opt != nullptr) {
                if (obj_support_opt != nullptr)
                    obj_support = obj_support_opt->getBool();
                if (obj_raft_opt != nullptr)
                    obj_support |= obj_raft_opt->getInt() > 0;
            }
            else
                obj_support = glb_support;

            if (!obj_support)
                continue;

            int obj_support_intf_extr = 0;
            const ConfigOption* support_intf_extr_opt = object->config.option("support_interface_filament");
            if (support_intf_extr_opt != nullptr)
                obj_support_intf_extr = support_intf_extr_opt->getInt();
            if (obj_support_intf_extr != 0)
                plate_extruders.push_back(obj_support_intf_extr);
            else if (glb_support_intf_extr != 0)
                plate_extruders.push_back(glb_support_intf_extr);

            int obj_support_extr = 0;
            const ConfigOption* support_extr_opt = object->config.option("support_filament");
            if (support_extr_opt != nullptr)
                obj_support_extr = support_extr_opt->getInt();
            if (obj_support_extr != 0)
                plate_extruders.push_back(obj_support_extr);
            else if (glb_support_extr != 0)
                plate_extruders.push_back(glb_support_extr);
        }
    }

    if (conside_custom_gcode) {
        //BBS
        int nums_extruders = 0;
        if (const ConfigOptionStrings *color_option = dynamic_cast<const ConfigOptionStrings *>(full_config.option("filament_colour"))) {
            nums_extruders = color_option->values.size();
            if (m_model->plates_custom_gcodes.find(m_plate_index) != m_model->plates_custom_gcodes.end()) {
                for (auto item : m_model->plates_custom_gcodes.at(m_plate_index).gcodes) {
                    if (item.type == CustomGCode::Type::ToolChange && item.extruder <= nums_extruders)
                        plate_extruders.push_back(item.extruder);
                }
            }
        }
    }

    std::sort(plate_extruders.begin(), plate_extruders.end());
    auto it_end = std::unique(plate_extruders.begin(), plate_extruders.end());
    plate_extruders.resize(std::distance(plate_extruders.begin(), it_end));

    if (auto* is_mixed_opt = full_config.option<ConfigOptionBools>("filament_is_mixed")) {
        if (auto* comp_strs_opt = full_config.option<ConfigOptionStrings>("filament_mixed_components")) {
            if (has_any_mixed_filament(is_mixed_opt->values)) {
                std::vector<unsigned int> ext_0based;
                for (int e : plate_extruders)
                    if (e >= 1) ext_0based.push_back((unsigned int)(e - 1));
                auto expanded = expand_mixed_filaments(ext_0based, is_mixed_opt->values, comp_strs_opt->values);
                plate_extruders.clear();
                for (unsigned int e : expanded)
                    plate_extruders.push_back((int)(e + 1));
            }
        }
    }

    return plate_extruders;
}

bool PartPlate::check_objects_empty_and_gcode3mf(std::vector<int> &result) const
{
    if (m_model->objects.empty()) {//objects is empty
        if (wxGetApp().plater() && wxGetApp().plater()->is_gcode_3mf()) { // if gcode.3mf file
            for (int i = 0; i < slice_filaments_info.size(); i++) {
                result.push_back(slice_filaments_info[i].id + 1);
            }
        }
        return true;
    }
    return false;
}

std::vector<int> PartPlate::get_extruders_without_support(bool conside_custom_gcode) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/* -1 is invalid, return physical extruder idx*/

/* machine has 1 extruder*/
/* logical extruder: 0-unique*/
/* physical extruder: 0-unique*/

/* machine have 2 extruders*/
/* logical extruder: 0-left, 1-right*/
/* physical extruder: 0-right, 1-left*/
int PartPlate::get_physical_extruder_by_logical_extruder(const DynamicConfig& g_config, int logical_extruder) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/* logical extruder: 0-default 1-left, 2-right in filament_map*/
int PartPlate::get_physical_extruder_by_filament_id(const DynamicConfig& g_config, int idx) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

int PartPlate::get_logical_extruder_by_filament_id(const DynamicConfig& g_config, int idx) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */


std::vector<int> PartPlate::get_used_filaments()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_filament_printable(const DynamicPrintConfig &config, wxString& error_message)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_tpu_printable_status(const DynamicPrintConfig & config, const std::vector<int> &tpu_filaments)
{
	// do not limit the num of tpu filament in slicing
	return true;
}

bool PartPlate::check_multi_filament_without_prime_tower(const DynamicPrintConfig &config)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_mixture_of_pla_and_petg(const DynamicPrintConfig &config)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_mixture_filament_compatible(const DynamicPrintConfig &config, std::string &error_msg)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_compatible_of_nozzle_and_filament(const DynamicPrintConfig &config, const std::vector<std::string> &filament_presets, std::string &error_msg)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_flow_compatible_of_nozzle_and_filament(const DynamicPrintConfig &config, const std::vector<std::string> &filament_presets, std::string &error_msg)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_tpu_nozzle_has_multiple_filaments(const DynamicPrintConfig &config, std::string &error_msg)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_high_temp_need_wrapping_detection(const DynamicPrintConfig &config, std::string &warning_text) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_high_shrinkage_filament(const DynamicPrintConfig &config, std::string &filament_names_text) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::check_single_extruder_mixed_filament_risk(const DynamicPrintConfig &config, std::string &warning_text) const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/*Vec3d PartPlate::calculate_wipe_tower_size(const DynamicPrintConfig &config, const double w, const double wipe_volume, int plate_extruder_size, bool use_global_objects) const
{
    Vec3d  wipe_tower_size;
    double layer_height = 0.08f; // hard code layer height
    double max_height   = 0.f;
    wipe_tower_size.setZero();

    const ConfigOption *layer_height_opt = config.option("layer_height");
    if (layer_height_opt)
        layer_height = layer_height_opt->getFloat();

    std::vector<int> plate_extruders = get_extruders(true);
	plate_extruder_size = plate_extruders.size();
    if (plate_extruder_size == 0)
        return wipe_tower_size;

    for (int obj_idx = 0; obj_idx < m_model->objects.size(); obj_idx++) {
        if (!use_global_objects && !contain_instance_totally(obj_idx, 0))
            continue;

        BoundingBoxf3 bbox = m_model->objects[obj_idx]->bounding_box();
        max_height         = std::max(bbox.size().z(), max_height);
    }
    wipe_tower_size(2) = max_height;

    auto timelapse_type    = config.option<ConfigOptionEnum<TimelapseType>>("timelapse_type");
    bool timelapse_enabled = timelapse_type ? (timelapse_type->value == TimelapseType::tlSmooth) : false;
    int nozzle_nums = wxGetApp().preset_bundle->get_printer_extruder_count();
    double extra_spacing     = config.option("prime_tower_infill_gap")->getFloat() / 100.;
    double depth             = std::sqrt(wipe_volume * (nozzle_nums == 2 ? plate_extruder_size : (plate_extruder_size - 1)) / layer_height * extra_spacing);
    if (timelapse_enabled || plate_extruder_size > 1) {
        float min_wipe_tower_depth = WipeTower::get_limit_depth_by_height(max_height);
        depth = std::max((double) min_wipe_tower_depth, depth);
        wipe_tower_size(0) = wipe_tower_size(1) = depth;
    }

    return wipe_tower_size;
}*/

Vec3d PartPlate::estimate_wipe_tower_size(const DynamicPrintConfig & config, const double w, const double wipe_volume, int extruder_count, int plate_extruder_size, bool use_global_objects, bool enable_wrapping_detection) const
{
    Vec3d wipe_tower_size;
    double layer_height = 0.08f; // hard code layer height
    double max_height = 0.f;
    wipe_tower_size.setZero();

    const ConfigOption* layer_height_opt = config.option("layer_height");
    if (layer_height_opt)
        layer_height = layer_height_opt->getFloat();

    // empty plate
    if (plate_extruder_size == 0)
    {
        std::vector<int> plate_extruders = get_extruders(true);
        plate_extruder_size = plate_extruders.size();
    }
    if (plate_extruder_size == 0)
        return wipe_tower_size;

    for (int obj_idx = 0; obj_idx < m_model->objects.size(); obj_idx++) {
        if (!use_global_objects && !contain_instance_totally(obj_idx, 0))
            continue;
        auto mo = m_model->objects[obj_idx];
        for (size_t i = 0; i < mo->instances.size(); ++i) {
            BoundingBoxf3 bbox = mo->instance_bounding_box(i);
            max_height         = std::max(bbox.max.z(), max_height);
        }
    }
    wipe_tower_size(2) = max_height;
    //const DynamicPrintConfig &dconfig = wxGetApp().preset_bundle->prints.get_edited_preset().config;
    auto timelapse_type    = config.option<ConfigOptionEnum<TimelapseType>>("timelapse_type");
    bool need_wipe_tower = (timelapse_type ? (timelapse_type->value == TimelapseType::tlSmooth) : false) | enable_wrapping_detection;
    double extra_spacing     = config.option("prime_tower_infill_gap")->getFloat() / 100.;
    const ConfigOptionBool* use_rib_wall_opt = config.option<ConfigOptionBool>("prime_tower_rib_wall");
    bool use_rib_wall = use_rib_wall_opt ? use_rib_wall_opt->value: true;
    double rib_width = config.option("prime_tower_rib_width")->getFloat();
    double depth;
    double filament_change_volume=0.;
    {
        std::vector<double>             filament_change_lengths;
        auto                filament_change_lengths_opt = m_print->config().option<ConfigOptionFloats>("filament_change_length");
        if (filament_change_lengths_opt) filament_change_lengths = filament_change_lengths_opt->values;
        double length = filament_change_lengths.empty() ? 0 : *std::max_element(filament_change_lengths.begin(), filament_change_lengths.end());
        double diameter = 1.75;
        std::vector<double> diameters;
        auto                filament_diameter_opt = m_print->config().option<ConfigOptionFloats>("filament_diameter");
        if (filament_diameter_opt) diameters = filament_diameter_opt->values;
        diameter = diameters.empty() ? diameter : *std::max_element(diameters.begin(), diameters.end());
        filament_change_volume = length * PI * diameter * diameter / 4.;
    }
    double volume = wipe_volume * (extruder_count == 2 ? plate_extruder_size : (plate_extruder_size - 1));
    if (extruder_count == 2) volume += filament_change_volume * (int) (plate_extruder_size / 2);
    if (use_rib_wall) {
        depth = std::sqrt(volume / layer_height * extra_spacing);
        if (need_wipe_tower || plate_extruder_size > 1) {
            float min_wipe_tower_depth = WipeTower::get_limit_depth_by_height(max_height);
            double volume_depth         = depth;
            depth = std::max((double) min_wipe_tower_depth, depth);
            rib_width = std::min(rib_width, depth / 2);
            depth = rib_width / std::sqrt(2) + std::max(depth + m_print->config().prime_tower_extra_rib_length.value, volume_depth);
            wipe_tower_size(0) = wipe_tower_size(1) = depth;
        }
    }
    else {
        depth  =  volume/ (layer_height * w) *extra_spacing;
        if (need_wipe_tower || depth > EPSILON) {
            float min_wipe_tower_depth = WipeTower::get_limit_depth_by_height(max_height);
            depth = std::max((double)min_wipe_tower_depth, depth);
        }
        wipe_tower_size(0) = w;
        wipe_tower_size(1) = depth;
    }

    return wipe_tower_size;
}

arrangement::ArrangePolygon PartPlate::estimate_wipe_tower_polygon(const DynamicPrintConfig& config, int plate_index, Vec3d& wt_pos, Vec3d& wt_size, int extruder_count, int plate_extruder_size, bool use_global_objects) const
{
	float x = dynamic_cast<const ConfigOptionFloats*>(config.option("wipe_tower_x"))->get_at(plate_index);
	float y = dynamic_cast<const ConfigOptionFloats*>(config.option("wipe_tower_y"))->get_at(plate_index);
	float w = dynamic_cast<const ConfigOptionFloat*>(config.option("prime_tower_width"))->value;
	//float a = dynamic_cast<const ConfigOptionFloat*>(config.option("wipe_tower_rotation_angle"))->value;
	std::vector<double> v = dynamic_cast<const ConfigOptionFloats*>(config.option("filament_prime_volume"))->values;
	if (config.option<ConfigOptionEnum<PrimeVolumeMode>>("prime_volume_mode")->value == pvmSaving) {
		for (auto& val : v)
			val = 15.f;
	}
    const ConfigOptionBool * wrapping_opt = dynamic_cast<const ConfigOptionBool *>(config.option("enable_wrapping_detection"));
	bool enable_wrapping = (wrapping_opt != nullptr) && wrapping_opt->value;
	wt_size = estimate_wipe_tower_size(config, w, get_max_element(v), extruder_count, plate_extruder_size, use_global_objects, enable_wrapping);
	int plate_width=m_width, plate_depth=m_depth;
	float depth = wt_size(1);
	float margin = WIPE_TOWER_MARGIN, wp_brim_width = 0.f;
	const ConfigOption* wipe_tower_brim_width_opt = config.option("prime_tower_brim_width");
	if (wipe_tower_brim_width_opt) {
		wp_brim_width = wipe_tower_brim_width_opt->getFloat();
        if (wp_brim_width < 0) wp_brim_width = WipeTower::get_auto_brim_by_height((float) wt_size.z());
		BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format("arrange wipe_tower: wp_brim_width %1%") % wp_brim_width;
	}

	x = std::clamp(x, margin, (float)plate_width - w - margin - wp_brim_width);
    y = std::clamp(y, margin, (float)plate_depth - depth - margin - wp_brim_width);
    wt_pos(0) = x;
    wt_pos(1) = y;
    wt_pos(2) = 0.f;

	arrangement::ArrangePolygon wipe_tower_ap;
	Polygon ap({
		{scaled(x - wp_brim_width), scaled(y - wp_brim_width)},
		{scaled(x + w + wp_brim_width), scaled(y - wp_brim_width)},
		{scaled(x + w + wp_brim_width), scaled(y + depth + wp_brim_width)},
		{scaled(x - wp_brim_width), scaled(y + depth + wp_brim_width)}
		});
	wipe_tower_ap.bed_idx = plate_index;
	wipe_tower_ap.setter = NULL; // do not move wipe tower

	wipe_tower_ap.poly.contour = std::move(ap);
	wipe_tower_ap.translation = { scaled(0.f), scaled(0.f) };
	//wipe_tower_ap.rotation = a;
	wipe_tower_ap.name = "WipeTower";
	wipe_tower_ap.is_virt_object = true;
	wipe_tower_ap.is_wipe_tower = true;

	return wipe_tower_ap;
}

bool PartPlate::operator<(PartPlate& plate) const
{
	int index = plate.get_index();
	return (this->m_plate_index < index);
}

//set the plate's index
void PartPlate::set_index(int index)
{
	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": plate_id update from %1% to %2%") % m_plate_index % index;

	m_plate_index = index;
	if (m_print != nullptr)
		m_print->set_plate_index(index);
}

void PartPlate::clear(bool clear_sliced_result)
{
	obj_to_instance_set.clear();
	instance_outside_set.clear();
	if (clear_sliced_result) {
		m_ready_for_slice = true;
		update_slice_result_valid_state(false);
	}

	return;
}

/* size and position related functions*/
//set position and size
void PartPlate::set_pos_and_size(Vec3d& origin, int width, int depth, int height, bool with_instance_move, bool do_clear)
{
	bool size_changed = false; //size changed means the machine changed
	bool pos_changed = false;

	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate_id %1%, before, origin {%2%,%3%,%4%}, plate_width %5%, plate_depth %6%, plate_height %7%")\
		% m_plate_index % m_origin.x() % m_origin.y() % m_origin.z() % m_width % m_depth % m_height;
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": with_instance_move %1%, after, origin {%2%,%3%,%4%}, plate_width %5%, plate_depth %6%, plate_height %7%")\
		% with_instance_move % origin.x() % origin.y() % origin.z() % width % depth % height;
	size_changed = ((width != m_width) || (depth != m_depth) || (height != m_height));
	pos_changed = (m_origin != origin);

	if ((!size_changed) && (!pos_changed))
	{
		//size and position the same with before, just return
		return;
	}

	if (with_instance_move && m_model)
	{
		for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it) {
			int obj_id = it->first;
			int instance_id = it->second;
			ModelObject* object = m_model->objects[obj_id];
			ModelInstance* instance = object->instances[instance_id];

			//move this instance into the new plate's same position
			Vec3d offset = instance->get_transformation().get_offset();
			int off_x, off_y;

			if (size_changed)
			{
				//change position due to the bed size changes
				//off_x = (width - m_width) * m_plate_index + (width - m_width) / 2;
				//off_y = (depth - m_depth) * m_plate_index + (depth - m_depth) / 2;
				off_x = origin.x() - m_origin.x() + (width - m_width) / 2;
				off_y = origin.y() - m_origin.y() + (depth - m_depth) / 2;
			}
			else
			{
				//change position due to the plate moves
				off_x = origin.x() - m_origin.x();
				off_y = origin.y() - m_origin.y();
			}
			offset.x() = offset.x() + off_x;
			offset.y() = offset.y() + off_y;

			BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": object %1%, instance %2%, moved {%3%,%4%} to {%5%, %6%}")\
				% obj_id % instance_id % off_x % off_y % offset.x() % offset.y();

			instance->set_offset(offset);
			object->invalidate_bounding_box();
		}
	}
	else if (do_clear)
	{
		clear();
	}

    if (m_print)
        m_print->set_plate_origin(origin);

	m_origin = origin;
	m_width = width;
	m_depth = depth;
	m_height = height;

	if (with_instance_move && m_plater)
		m_plater->mark_plate_toolbar_image_dirty();

	return;
}

//get the plate's center point origin
Vec3d PartPlate::get_center_origin()
{
	Vec3d origin;

	// Virtual / unprintable plate has no m_shape and a degenerate bbox; fall
	// back to origin+size. Real plates keep the bbox formula for non-rect beds.
	if (m_shape.empty()) {
		origin(0) = m_origin.x() + m_width / 2.0;
		origin(1) = m_origin.y() + m_depth / 2.0;
	} else {
		origin(0) = (m_bounding_box.min(0) + m_bounding_box.max(0)) / 2;//m_origin.x() + m_width / 2;
		origin(1) = (m_bounding_box.min(1) + m_bounding_box.max(1)) / 2; //m_origin.y() + m_depth / 2;
	}
	origin(2) = m_origin.z();

	return origin;
}

bool PartPlate::generate_plate_name_texture()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::string remove_invisible_ascii(const std::string &name)
{
	std::string new_name;
	for (size_t i = 0; i < name.size(); i++) {
		if (int(name[i]) >= 0 && int(name[i]) < 32) { // 0x00 - 0x1F
			continue;
		}
		new_name += name[i];
	}
	return new_name;
}

void PartPlate::set_plate_name(const std::string &name)
{
	// compare if name equal to m_name, case sensitive
	if (boost::equals(m_name, name)) return;
	if (Plater::has_illegal_filename_characters(name)) {
		if(m_plater)
			Plater::show_illegal_characters_warning(m_plater);
		return;
	}
	if (m_plater)
		m_plater->take_snapshot("set_plate_name");
	m_name = remove_invisible_ascii(name);
	m_name_change = true;
	if (m_plater) {
		ObjectList *obj_list = wxGetApp().obj_list();
		if (obj_list) {
			obj_list->GetModel()->SetCurSelectedPlateFullName(m_plate_index, m_name);
		}
	}
	if (m_print != nullptr)
		m_print->set_plate_name(m_name);
}

//get the print's object, result and index
void PartPlate::get_print(PrintBase** print, GCodeResult** result, int* index)
{
	if (print && (printer_technology == PrinterTechnology::ptFFF))
		*print = m_print;

	if (result)
		*result = m_gcode_result;

	if (index)
		*index = m_print_index;

	return;
}

GCodeProcessorResult *PartPlate::get_gcode_result()
{ return {}; } /* WASM: çizim kodu kaldırıldı */


//set the print object, result and it's index
void PartPlate::set_print(PrintBase* print, GCodeResult* result, int index)
{
	if (printer_technology == PrinterTechnology::ptFFF)
		m_print = static_cast<Print*>(print);
	//todo, for other printers

	m_gcode_result = result;
	if (index >= 0)
		m_print_index = index;

	m_print->set_plate_origin(m_origin);

	return;
}

std::string PartPlate::get_gcode_filename()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::is_valid_gcode_file()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

ModelObjectPtrs PartPlate::get_objects_on_this_plate() {
    ModelObjectPtrs objects_ptr;
    int obj_id;
    for (auto it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); it++) {
        obj_id = it->first;
        objects_ptr.push_back(m_model->objects[obj_id]);
    }
    return objects_ptr;
}

ModelInstance* PartPlate::get_instance(int obj_id, int instance_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/* instance related operations*/
//judge whether instance is bound in plate or not
bool PartPlate::contain_instance(int obj_id, int instance_id)
{
	bool result = false;
	std::set<std::pair<int, int>>::iterator it;

	it = obj_to_instance_set.find(std::pair(obj_id, instance_id));
	if (it != obj_to_instance_set.end()) {
		result = true;
	}

	return result;
}

//judge whether instance is bound in plate or not
bool PartPlate::contain_instance_totally(ModelObject* object, int instance_id) const
{
	bool result = false;
	int obj_id = -1;

	for (int index = 0; index < m_model->objects.size(); index ++)
	{
		if (m_model->objects[index] == object)
		{
			obj_id = index;
			break;
		}
	}

	if ((obj_id >= 0 ) && (obj_id < m_model->objects.size()))
		result = contain_instance_totally(obj_id, instance_id);

	return result;
}

//judge whether instance is totally included in plate or not
bool PartPlate::contain_instance_totally(int obj_id, int instance_id) const
{
	bool result = false;
	std::set<std::pair<int, int>>::iterator it;

	it = obj_to_instance_set.find(std::pair(obj_id, instance_id));
	if (it != obj_to_instance_set.end()) {
		it = instance_outside_set.find(std::pair(obj_id, instance_id));
		if (it == instance_outside_set.end())
			result = true;
	}

	return result;
}

//check whether instance is outside the plate or not
bool PartPlate::check_outside(int obj_id, int instance_id, BoundingBoxf3* bounding_box)
{
	bool outside = true;

	ModelObject* object = m_model->objects[obj_id];
	ModelInstance* instance = object->instances[instance_id];

	BoundingBoxf3 instance_box = bounding_box? *bounding_box: object->instance_convex_hull_bounding_box(instance_id);
	Polygon hull = instance->convex_hull_2d();
	BoundingBoxf3 plate_box = get_plate_box();
	if (instance_box.max.z() > plate_box.min.z())
		plate_box.min.z() += instance_box.min.z(); // not considering outsize if sinking

	if (plate_box.contains(instance_box))
	{
		if (m_exclude_bounding_box.size() > 0)
		{
			int index;
			for (index = 0; index < m_exclude_bounding_box.size(); index ++)
			{
				Polygon p = m_exclude_bounding_box[index].polygon(true);  // instance convex hull is scaled, so we need to scale here
				if (intersection({ p }, { hull }).empty() == false)
				//if (m_exclude_bounding_box[index].intersects(instance_box))
				{
					break;
				}
			}
			if (index >= m_exclude_bounding_box.size())
				outside = false;
		}
		else
			outside = false;
	}

	return outside;
}

//judge whether instance is intesected with plate or not
bool PartPlate::intersect_instance(int obj_id, int instance_id, BoundingBoxf3* bounding_box)
{
	bool result = false;

	if (!valid_instance(obj_id, instance_id))
	{
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << boost::format(": plate_id %1%, invalid obj_id %2%, instance_id %3%") % m_plate_index % obj_id % instance_id;
		return false;
	}

	if (m_printable)
	{
		ModelObject* object = m_model->objects[obj_id];
		ModelInstance* instance = object->instances[instance_id];
		BoundingBoxf3 instance_box = bounding_box? *bounding_box: object->instance_convex_hull_bounding_box(instance_id);
		result = get_plate_box().intersects(instance_box);
	}
	else
	{
		// Virtual plate: is_left_top_of() doesn't apply, use bbox intersection.
		ModelObject*  object       = m_model->objects[obj_id];
		BoundingBoxf3 instance_box = bounding_box ? *bounding_box : object->instance_convex_hull_bounding_box(instance_id);
		result = get_plate_box().intersects(instance_box);
	}

	return result;
}

//judge whether the plate's origin is at the left of instance or not
bool PartPlate::is_left_top_of(int obj_id, int instance_id)
{
	bool result = false;

	if (!valid_instance(obj_id, instance_id))
	{
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << boost::format(": plate_id %1%, invalid obj_id %2%, instance_id %3%") % m_plate_index % obj_id % instance_id;
		return false;
	}

	ModelObject* object = m_model->objects[obj_id];
	ModelInstance* instance = object->instances[instance_id];
	std::pair<int, int> pair(obj_id, instance_id);
	BoundingBoxf3 instance_box = object->instance_convex_hull_bounding_box(instance_id);

	result = (m_origin.x() <= instance_box.min.x()) && (m_origin.y() >= instance_box.min.y());
	return result;
}

//add an instance into plate
int PartPlate::add_instance(int obj_id, int instance_id, bool move_position, BoundingBoxf3* bounding_box)
{
	if (!valid_instance(obj_id, instance_id))
	{
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << boost::format(": plate_id %1%, invalid obj_id %2%, instance_id %3%, move_position %4%") % m_plate_index % obj_id % instance_id % move_position;
		return -1;
	}

	ModelObject* object = m_model->objects[obj_id];
	ModelInstance* instance = object->instances[instance_id];
	std::pair<int, int> pair(obj_id, instance_id);

    obj_to_instance_set.insert(pair);

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": plate_id %1%, add instance obj_id %2%, instance_id %3%, move_position %4%") % m_plate_index % obj_id % instance_id % move_position;

	if (move_position)
	{
		//move this instance into the new position
		Vec3d center = get_center_origin();
		center.z() = instance->get_transformation().get_offset(Z);

		instance->set_offset(center);
		object->invalidate_bounding_box();
	}

	//need to judge whether this instance has an outer part
	bool outside = check_outside(obj_id, instance_id, bounding_box);
	if (outside)
		instance_outside_set.insert(pair);

	if (m_ready_for_slice && outside)
	{
		m_ready_for_slice = false;
	}
	else if ((obj_to_instance_set.size() == 1) && (!m_ready_for_slice) && !outside)
	{
		m_ready_for_slice = true;
	}

	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1% , m_ready_for_slice changes to %2%") % m_plate_index %m_ready_for_slice;
	if (m_plater)
		m_plater->mark_plate_toolbar_image_dirty();
	return 0;
}

//remove instance from plate
int PartPlate::remove_instance(int obj_id, int instance_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

BoundingBoxf3 PartPlate::get_objects_bounding_box()
{
    BoundingBoxf3 bbox;
    for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
    {
        int obj_id = it->first;
        int instance_id = it->second;

        if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
        {
            ModelObject* object = m_model->objects[obj_id];
            if ((instance_id >= 0) && (instance_id < object->instances.size()))
            {
                BoundingBoxf3 instance_bbox = object->instance_bounding_box(instance_id);
                bbox.merge(instance_bbox);
            }
        }
    }
    return bbox;
}


//translate instance on the plate
void PartPlate::translate_all_instance(Vec3d position)
{
    for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
    {
        int obj_id = it->first;
        int instance_id = it->second;

        if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
        {
            ModelObject* object = m_model->objects[obj_id];
            if ((instance_id >= 0) && (instance_id < object->instances.size()))
            {
                ModelInstance* instance = object->instances[instance_id];
                const Vec3d& offset =  instance->get_offset();
                instance->set_offset(offset + position);
            }
        }
    }
    return;
}

void PartPlate::duplicate_all_instance(unsigned int dup_count, bool need_skip, std::map<int, bool>& skip_objects)
{
    std::set<std::pair<int, int>> old_obj_list = obj_to_instance_set;
    BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": plate_id %1%, dup_count %2%") % m_plate_index % dup_count;
    for (std::set<std::pair<int, int>>::iterator it = old_obj_list.begin(); it != old_obj_list.end(); ++it)
    {
        int obj_id = it->first;
        int instance_id = it->second;

        if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
        {
            ModelObject* object = m_model->objects[obj_id];
            ModelInstance* instance = object->instances[instance_id];

            if (need_skip)
            {
                if (skip_objects.find(instance->loaded_id) != skip_objects.end())
                {
                    instance->printable = false;
                    BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": skipped object, loaded_id %1%, name %2%, set to unprintable, no need to duplicate") % instance->loaded_id % object->name;
                    continue;
                }
            }
            for (size_t index = 0; index < dup_count; index ++)
            {
                ModelObject* newObj = m_model->add_object(*object);
                newObj->name = object->name +"_"+ std::to_string(index+1);
                int new_obj_id = m_model->objects.size() - 1;
                for ( size_t new_instance_id = 0; new_instance_id < newObj->instances.size(); new_instance_id++ )
                {
                    obj_to_instance_set.emplace(std::pair(new_obj_id, new_instance_id));
                    BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": duplicate object into plate: index_pair [%1%,%2%], obj_id %3%") % new_obj_id % new_instance_id % newObj->id().id;
                }
            }
        }
    }

    for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
    {
        int obj_id = it->first;
        int instance_id = it->second;

        if ((obj_id >= 0) && (obj_id < m_model->objects.size()))
        {
            ModelObject* object = m_model->objects[obj_id];
            ModelInstance* instance = object->instances[instance_id];

            if (instance->printable)
            {
                instance->loaded_id = instance->id().id;
                if (need_skip) {
                    while (skip_objects.find(instance->loaded_id) != skip_objects.end())
                    {
                        instance->loaded_id ++;
                        BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": duplicated id %1% with skip, try new one %2%") %instance->id().id  % instance->loaded_id;
                    }
                }
                BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": set obj %1% instance %2%'s loaded_id to its id %3%, name %4%") % obj_id %instance_id %instance->loaded_id  % object->name;
            }
        }
    }

    return;
}



//update instance exclude state
void PartPlate::update_instance_exclude_status(int obj_id, int instance_id, BoundingBoxf3* bounding_box)
{} /* WASM: çizim kodu kaldırıldı */

//update object's index caused by original object deleted
void PartPlate::update_object_index(int obj_idx_removed, int obj_idx_max)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_vase_mode_related_object_config(int obj_id) {} /* WASM: çizim kodu kaldırıldı */

int PartPlate::printable_instance_size()
{
    int size = 0;
    for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it) {
        int obj_id      = it->first;
        int instance_id = it->second;

        if (obj_id >= m_model->objects.size())
			continue;

        ModelObject *  object   = m_model->objects[obj_id];
        ModelInstance *instance = object->instances[instance_id];

        if ((instance->printable) && (instance_outside_set.find(std::pair(obj_id, instance_id)) == instance_outside_set.end())) {
            size++;
        }
    }
    return size;
}

//whether it is has printable instances
bool PartPlate::has_printable_instances()
{
	bool result = false;

	for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
	{
		int obj_id = it->first;
		int instance_id = it->second;

		if (obj_id >= m_model->objects.size())
			continue;

		ModelObject* object = m_model->objects[obj_id];
		ModelInstance* instance = object->instances[instance_id];

		if ((instance->printable)&&(instance_outside_set.find(std::pair(obj_id, instance_id)) == instance_outside_set.end()))
		{
			result = true;
			break;
		}
	}

	return result;
}

bool PartPlate::is_all_instances_unprintable()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//move instances to left or right PartPlate
void PartPlate::move_instances_to(PartPlate& left_plate, PartPlate& right_plate, BoundingBoxf3* bounding_box)
{
	for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it)
	{
		int obj_id = it->first;
		int instance_id = it->second;

		if (left_plate.intersect_instance(obj_id, instance_id, bounding_box))
			left_plate.add_instance(obj_id, instance_id, false, bounding_box);
		else
			right_plate.add_instance(obj_id, instance_id, false, bounding_box);
	}

	return;
}

void PartPlate::generate_logo_polygon(ExPolygon &logo_polygon)
{
    auto &cur_shape = m_partplate_list->m_shape;
    if (cur_shape.size() == 4) { // rectangle case
		for (int i = 0; i < 4; i++){
            const Vec2d &p = cur_shape[i];
			if ((i  == 0) || (i  == 1)) {
				logo_polygon.contour.append({ scale_(p(0)), scale_(p(1) - 10.f) });
			}
			else {
				logo_polygon.contour.append({scale_(p(0)), scale_(p(1) + 10.f)});
			}
		}
	}
	else {
        for (const Vec2d &p : cur_shape) {
			logo_polygon.contour.append({ scale_(p(0)), scale_(p(1)) });
		}
	}
}

void PartPlate::generate_logo_polygon(ExPolygon &logo_polygon, const BoundingBoxf3 &box) {
    if (box.defined) {
		{
            Vec2d p(box.min.x(), box.min.y());
            logo_polygon.contour.append({scale_(p(0)), scale_(p(1))});
		}
        {
            Vec2d p(box.max.x(), box.min.y());
            logo_polygon.contour.append({scale_(p(0)), scale_(p(1))});
        }
        {
            Vec2d p(box.max.x(), box.max.y());
            logo_polygon.contour.append({scale_(p(0)), scale_(p(1))});
        }
        {
            Vec2d p(box.min.x(), box.max.y());
            logo_polygon.contour.append({scale_(p(0)), scale_(p(1))});
        }
	}
}

void PartPlate::set_logo_box_by_bed(const BoundingBoxf3& box)
{
    if (box.defined) {
        m_cur_bed_boundingbox = box;
        ExPolygon logo_poly;
        generate_logo_polygon(logo_poly, box);
        auto triangles = triangulate_expolygon_2f(logo_poly, NORMALS_UP);
        m_logo_triangles.reset();
        if (!m_logo_triangles.init_model_from_poly(triangles, GROUND_Z + 0.01f)) {
            BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << ":error :Unable to create logo triangles in set_logo_box_by_bed\n";
            return;
        }
	}
}

void PartPlate::generate_exclude_polygon(ExPolygon &exclude_polygon)
{
	auto compute_exclude_points = [&exclude_polygon](Vec2d& center, double radius, double start_angle, double stop_angle, int count)
	{
		double angle, angle_steps;
		angle_steps = (stop_angle - start_angle) / (count - 1);
		for(int j = 0; j < count; j++ )
		{
			double angle = start_angle + j * angle_steps;
			double x = center(0) + ::cos(angle) * radius;
			double y = center(1) + ::sin(angle) * radius;
			exclude_polygon.contour.append({ scale_(x), scale_(y) });
		}
	};

	int points_count = 8;
	if (m_exclude_area.size() == 4)
	{
			//rectangle case
			for (int i = 0; i < 4; i++)
			{
				const Vec2d& p = m_exclude_area[i];
				Vec2d center;
				double start_angle, stop_angle, angle_steps, radius_x, radius_y, radius;
				switch (i) {
					case 0:
                        radius = 8.f;
						center(0) = p(0) + radius;
						center(1) = p(1) + radius;
						start_angle = PI;
						stop_angle = 1.5 * PI;
						compute_exclude_points(center, radius, start_angle, stop_angle, points_count);
						break;
					case 1:
						exclude_polygon.contour.append({ scale_(p(0)), scale_(p(1)) });
						break;
					case 2:
						radius = 3.f;
						center(0) = p(0) - radius;
						center(1) = p(1) - radius;
						start_angle = 0;
						stop_angle = 0.5 * PI;
						compute_exclude_points(center, radius, start_angle, stop_angle, points_count);
						break;
					case 3:
						exclude_polygon.contour.append({ scale_(p(0)), scale_(p(1)) });
						break;
				}
			}
	}
	else {
		for (const Vec2d& p : m_exclude_area) {
			exclude_polygon.contour.append({ scale_(p(0)), scale_(p(1)) });
		}
	}
}

bool PartPlate::set_shape(const Pointfs& shape, const Pointfs& exclude_areas, const std::vector<Pointfs>& extruder_areas, const std::vector<double>& extruder_heights, Vec2d position, float height_to_lid, float height_to_rod)
{
	Pointfs new_shape, new_exclude_areas;
	m_raw_shape = shape;
	m_extruder_heights = extruder_heights;
	for (const Vec2d& p : shape) {
		new_shape.push_back(Vec2d(p.x() + position.x(), p.y() + position.y()));
	}

	for (const Vec2d& p : exclude_areas) {
		new_exclude_areas.push_back(Vec2d(p.x() + position.x(), p.y() + position.y()));
	}

	std::vector<Pointfs> new_extruder_areas;
	for (const Pointfs& shape : extruder_areas) {
		Pointfs new_extruder_area;
		for (const Vec2d& p : shape) {
			Vec2d point(p(0) + position.x(), p(1) + position.y());
			new_extruder_area.push_back(point);
		}
		new_extruder_areas.push_back(new_extruder_area);
	}
	m_extruder_areas = std::move(new_extruder_areas);

	if ((m_shape == new_shape)&&(m_exclude_area == new_exclude_areas)
		&&(m_height_to_lid == height_to_lid)&&(m_height_to_rod == height_to_rod)) {
		BOOST_LOG_TRIVIAL(info) << "PartPlate same shape, skip directly";
		return false;
	}

	m_height_to_lid =  height_to_lid;
	m_height_to_rod =  height_to_rod;

	if ((m_shape != new_shape) || (m_exclude_area != new_exclude_areas))
	{
		/*m_shape.clear();
		for (const Vec2d& p : shape) {
			m_shape.push_back(Vec2d(p.x() + position.x(), p.y() + position.y()));
		}

		m_exclude_area.clear();
		for (const Vec2d& p : exclude_areas) {
			m_exclude_area.push_back(Vec2d(p.x() + position.x(), p.y() + position.y()));
		}*/
		m_shape = std::move(new_shape);
		m_exclude_area = std::move(new_exclude_areas);

		calc_bounding_boxes();

		if (m_plater != nullptr) { // render data, skip in CLI mode where m_plater is null
			ExPolygon logo_poly;
			generate_logo_polygon(logo_poly);
			auto triangles = triangulate_expolygon_2f(logo_poly, NORMALS_UP);
			m_logo_triangles.reset();
			if (!m_logo_triangles.init_model_from_poly(triangles, GROUND_Z + 0.01f))
				BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << ":Unable to create logo triangles\n";
			else {
				;
			}
			BoundingBoxf3 box_in_plate_origin;
			if (calc_bed_3d_boundingbox(box_in_plate_origin)) {
				if ((m_cur_bed_boundingbox.center() - box_in_plate_origin.center()).norm() > 1.0f) {
					set_logo_box_by_bed(box_in_plate_origin);
				}
			}

			calc_vertex_for_plate_name(m_name_texture, m_plate_name_icon);//if (generate_plate_name_texture())
			calc_vertex_for_plate_name_edit_icon(&m_name_texture, 0, m_plate_name_edit_icon);
		}
	}
	calc_height_limit();

	release_opengl_resource();

	return true;
}

const BoundingBox PartPlate::get_bounding_box_crd()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

BoundingBoxf3 PartPlate::get_build_volume(bool use_share)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::contains(const Vec3d& point) const
{
	return m_bounding_box.contains(point);
}

bool PartPlate::contains(const GLVolume& v) const
{
	return m_bounding_box.contains(v.bounding_box());
}

bool PartPlate::contains(const BoundingBoxf3& bb) const
{
	// Allow the objects to protrude below the print bed
	BoundingBoxf3 print_volume(Vec3d(m_bounding_box.min(0), m_bounding_box.min(1), 0.0), Vec3d(m_bounding_box.max(0), m_bounding_box.max(1), 1e3));
	print_volume.min(2) = -1e10;
	print_volume.min(0) -= Slic3r::BuildVolume::BedEpsilon;
	print_volume.min(1) -= Slic3r::BuildVolume::BedEpsilon;
	print_volume.max(0) += Slic3r::BuildVolume::BedEpsilon;
	print_volume.max(1) += Slic3r::BuildVolume::BedEpsilon;
	return print_volume.contains(bb);
}

bool PartPlate::intersects(const BoundingBoxf3& bb) const
{
	// Allow the objects to protrude below the print bed
	BoundingBoxf3 print_volume(Vec3d(m_bounding_box.min(0), m_bounding_box.min(1), 0.0), Vec3d(m_bounding_box.max(0), m_bounding_box.max(1), 1e3));
	print_volume.min(2) = -1e10;
	print_volume.min(0) -= Slic3r::BuildVolume::BedEpsilon;
	print_volume.min(1) -= Slic3r::BuildVolume::BedEpsilon;
	print_volume.max(0) += Slic3r::BuildVolume::BedEpsilon;
	print_volume.max(1) += Slic3r::BuildVolume::BedEpsilon;
	return print_volume.intersects(bb);
}

void PartPlate::render(bool bottom, bool only_body, bool force_background_color, HeightLimitMode mode, int hover_id, bool render_cali)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_selected() {
	m_selected = true;
}

void PartPlate::set_unselected() {
	m_selected = false;
}


/*status related functions*/
//update status
void PartPlate::update_states()
{} /* WASM: çizim kodu kaldırıldı */

/*slice related functions*/
//invalid sliced result
void PartPlate::update_slice_result_valid_state(bool valid)
{
    BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1% , update slice result from %2% to %3%") % m_plate_index %m_slice_result_valid %valid;
    m_slice_result_valid = valid;
    if (valid)
        m_slice_percent = 100.0f;
    else {
        m_slice_percent = -1.0f;
        // helio results cleared in restart_background_process() when slicing actually starts,
        // not here, to preserve results on plates that are not being resliced.
    }
}

// Helio result per-plate storage
const HelioPlateResult* PartPlate::get_helio_result() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_helio_result(const HelioPlateResult& result)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::clear_helio_result()
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlate::has_helio_result() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//update current slice context into backgroud slicing process
void PartPlate::update_slice_context(BackgroundSlicingProcess & process)
{} /* WASM: çizim kodu kaldırıldı */

// BBS: delay calc gcode path in backup dir
std::string PartPlate::get_tmp_gcode_path()
{
    if (m_tmp_gcode_path.empty()) {
        boost::filesystem::path temp_path(m_model->get_backup_path("Metadata"));
        temp_path /= (boost::format(".%1%.%2%.gcode") % get_current_pid() %
                      GLOBAL_PLATE_INDEX++).str();
        m_tmp_gcode_path = temp_path.string();
    }
    return m_tmp_gcode_path;
}

std::string PartPlate::get_temp_config_3mf_path()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

// load gcode from file
int PartPlate::load_gcode_from_file(const std::string& filename)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

int PartPlate::load_thumbnail_data(std::string filename, ThumbnailData& thumb_data)
{
	bool result = true;
	wxImage img;
	if (boost::algorithm::iends_with(filename, ".png")) {
		result = img.LoadFile(wxString::FromUTF8(filename.c_str()), wxBITMAP_TYPE_PNG);
		img = img.Mirror(false);
	}
	if (result) {
		thumb_data.set(img.GetWidth(), img.GetHeight());
		for (int i = 0; i < img.GetWidth() * img.GetHeight(); i++) {
			memcpy(&thumb_data.pixels[4 * i], (unsigned char*)(img.GetData() + 3 * i), 3);
			if (img.HasAlpha()) {
				thumb_data.pixels[4 * i + 3] = *(unsigned char*)(img.GetAlpha() + i);
			}
		}
	} else {
		return -1;
	}
	return 0;
}

int PartPlate::load_pattern_thumbnail_data(std::string filename)
{
	/*bool result = true;
	wxImage img;
	result = load_image(filename, img);
	if (result) {
		cali_thumbnail_data.set(img.GetWidth(), img.GetHeight());
		for (int i = 0; i < img.GetWidth() * img.GetHeight(); i++) {
			memcpy(&cali_thumbnail_data.pixels[4 * i], (unsigned char*)(img.GetData() + 3 * i), 3);
			if (img.HasAlpha()) {
				cali_thumbnail_data.pixels[4 * i + 3] = *(unsigned char*)(img.GetAlpha() + i);
			}
		}
	}
	else {
		return -1;
	}*/
	return 0;
}

//load pattern box data from file
int PartPlate::load_pattern_box_data(std::string filename)
{
    try {
        nlohmann::json j;
        boost::nowide::ifstream ifs(filename);
        ifs >> j;

        PlateBBoxData bbox_data;
        bbox_data.from_json(j);
        cali_bboxes_data = bbox_data;
        return 0;
    }
    catch(std::exception &ex) {
        BOOST_LOG_TRIVIAL(trace) << boost::format("catch an exception %1%")%ex.what();
        return -1;
    }
}

std::vector<int> PartPlate::get_first_layer_print_sequence() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::vector<LayerPrintSequence> PartPlate::get_other_layers_print_sequence() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_first_layer_print_sequence(const std::vector<int>& sorted_filaments)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_other_layers_print_sequence(const std::vector<LayerPrintSequence>& layer_seq_list)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::update_first_layer_print_sequence(size_t filament_nums)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::update_first_layer_print_sequence_when_delete_filament(size_t filament_id)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::print() const
{
	unsigned int count=0;

	BOOST_LOG_TRIVIAL(trace) << __FUNCTION__ << boost::format(": plate index %1%, pointer %2%, print_index %3% print pointer %4%") % m_plate_index % this % m_print_index % m_print;
	BOOST_LOG_TRIVIAL(trace) << boost::format("\t origin {%1%,%2%,%3%}, width %4%,  depth %5%, height %6%") % m_origin.x() % m_origin.y() % m_origin.z() % m_width % m_depth % m_height;
	BOOST_LOG_TRIVIAL(trace) << boost::format("\t m_printable %1%, m_locked %2%, m_ready_for_slice %3%, m_slice_result_valid %4%,  m_tmp_gcode_path %5%, set size %6%")\
		% m_printable % m_locked % m_ready_for_slice % m_slice_result_valid % PathSanitizer::sanitize(m_tmp_gcode_path) % obj_to_instance_set.size();
	/*for (std::set<std::pair<int, int>>::iterator it = obj_to_instance_set.begin(); it != obj_to_instance_set.end(); ++it) {
		int obj_id = it->first;
		int instance_id = it->second;

		BOOST_LOG_TRIVIAL(trace) << boost::format("\t the %1%th instance, obj_id %2%, instance id %3%") % count++ % obj_id % instance_id;
	}*/
	BOOST_LOG_TRIVIAL(trace) << boost::format("excluded instance set size %1%")%instance_outside_set.size();
	/*for (std::set<std::pair<int, int>>::iterator it = instance_outside_set.begin(); it != instance_outside_set.end(); ++it) {
		int obj_id = it->first;
		int instance_id = it->second;

		BOOST_LOG_TRIVIAL(trace) << boost::format("\t obj_id %1%, instance id %2%") % obj_id % instance_id;
	}*/

	return;
}

std::map<std::string, std::string> PartPlate::get_diff_object_setting()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::map<std::string, std::string> PartPlate::get_diff_plate_setting()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlate::has_different_extruder_types()
{
    const auto &preset_bundle = wxGetApp().preset_bundle;
    const auto &full_config = preset_bundle->full_config();
    auto extruder_type_opt = full_config.option<ConfigOptionEnumsGeneric>("extruder_type");

    if (!extruder_type_opt || extruder_type_opt->values.size() < 2)
        return false;

    // Check if all extruder types are the same
    int first_type = extruder_type_opt->values[0];
    for (size_t i = 1; i < extruder_type_opt->values.size(); ++i) {
        if (extruder_type_opt->values[i] != first_type)
            return true;
    }

    return false;
}

FilamentMapMode PartPlate::get_filament_map_mode() const
{
    std::string key = "filament_map_mode";
    if(m_config.has(key))
        return m_config.option<ConfigOptionEnum<FilamentMapMode>>(key)->value;
    return FilamentMapMode::fmmDefault;
}

void PartPlate::set_filament_map_mode(const FilamentMapMode& mode)
{
	const auto& proj_config = wxGetApp().preset_bundle->project_config;
	FilamentMapMode global_mode = proj_config.option<ConfigOptionEnum<FilamentMapMode>>("filament_map_mode")->value;
	FilamentMapMode old_mode = get_filament_map_mode();
	FilamentMapMode old_real_mode = old_mode == fmmDefault ? global_mode : old_mode;
	FilamentMapMode new_real_mode = mode == fmmDefault ? global_mode : mode;

	if (old_real_mode != new_real_mode){
		clear_filament_map();
		clear_filament_nozzle_map();
		clear_filament_volume_map();
	}
	if (mode == fmmDefault)
		clear_filament_map_mode();
	else
		m_config.option<ConfigOptionEnum<FilamentMapMode>>("filament_map_mode", true)->value = mode;
}

std::vector<int> PartPlate::get_filament_maps() const
{
    std::string key = "filament_map";
    if (m_config.has(key))
        return m_config.option<ConfigOptionInts>(key)->values;

    return {};
}

void PartPlate::set_filament_maps(const std::vector<int>& f_maps)
{
    m_config.option<ConfigOptionInts>("filament_map", true)->values = f_maps;
}

std::vector<int> PartPlate::get_filament_nozzle_maps() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_filament_nozzle_maps(const std::vector<int>& f_maps)
{
	m_config.option<ConfigOptionInts>("filament_nozzle_map", true)->values = f_maps;
}

std::vector<int> PartPlate::get_filament_volume_maps() const
{
	if(m_config.has("filament_volume_map"))
		return m_config.option<ConfigOptionInts>("filament_volume_map")->values;
	return {};
}

void PartPlate::set_filament_volume_maps(const std::vector<int>& f_maps)
{
	m_config.option<ConfigOptionInts>("filament_volume_map", true)->values = f_maps;
}

void PartPlate::clear_filament_nozzle_map()
{
	if(m_config.has("filament_nozzle_map"))
		m_config.erase("filament_nozzle_map");
}

void PartPlate::clear_filament_volume_map()
{
	if(m_config.has("filament_volume_map"))
		m_config.erase("filament_volume_map");
}

void PartPlate::clear_filament_map()
{
    if (m_config.has("filament_map"))
        m_config.erase("filament_map");
}

void PartPlate::clear_filament_map_mode()
{
    if (m_config.has("filament_map_mode"))
        m_config.erase("filament_map_mode");
}

void PartPlate::on_extruder_count_changed(int extruder_count)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::set_filament_count(int filament_count)
{
    if (m_config.has("filament_map")) {
        std::vector<int>& filament_maps = m_config.option<ConfigOptionInts>("filament_map")->values;
        filament_maps.resize(filament_count, 1);
    }

	if(m_config.has("filament_nozzle_map")){
		std::vector<int>& filament_nozzle_map = m_config.option<ConfigOptionInts>("filament_nozzle_map")->values;
		filament_nozzle_map.resize(filament_count, 0);
	}
	if (m_config.has("filament_volume_map")) {
		std::vector<int>& filament_volume_map = m_config.option<ConfigOptionInts>("filament_volume_map")->values;
		filament_volume_map.resize(filament_count, static_cast<int>(NozzleVolumeType::nvtStandard));
	}

}

void PartPlate::on_filament_added()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlate::on_filament_deleted(int filament_count, int filament_id)
{} /* WASM: çizim kodu kaldırıldı */

/* PartPlate List related functions*/
PartPlateList::PartPlateList(int width, int depth, int height, Plater* platerObj, Model* modelObj, PrinterTechnology tech)
	:m_plate_width(width), m_plate_depth(depth), m_plate_height(height), m_plater(platerObj), m_model(modelObj), printer_technology(tech),
	unprintable_plate(this, Vec3d(0.0 + width * (1. + LOGICAL_PART_PLATE_GAP), 0.0, 0.0), width, depth, height, platerObj, modelObj, false, tech)
{
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":plate_width %1%, plate_depth %2%, plate_height %3%") % width % depth % height;

	init();
}
PartPlateList::PartPlateList(Plater* platerObj, Model* modelObj, PrinterTechnology tech)
	:m_plate_width(0), m_plate_depth(0), m_plate_height(0), m_plater(platerObj), m_model(modelObj), printer_technology(tech),
	unprintable_plate(this, Vec3d(0.0, 0.0, 0.0), m_plate_width, m_plate_depth, m_plate_height, platerObj, modelObj, false, tech)
{
	init();
}

PartPlateList::~PartPlateList()
{
	clear(true, true);
	release_icon_textures();
}

void PartPlateList::init()
{
	m_intialized = false;
	PartPlate* first_plate = NULL;
	first_plate = new PartPlate(this, Vec3d(0.0, 0.0, 0.0), m_plate_width, m_plate_depth, m_plate_height, m_plater, m_model, true, printer_technology);
	assert(first_plate != NULL);
	m_plate_list.push_back(first_plate);
    update_plate_trans(1);

	m_print_index = 0;
	if (printer_technology == ptFFF)
	{
		Print* print = new Print();
		GCodeResult* gcode = new GCodeResult();
		m_print_list.emplace(m_print_index, print);
		m_gcode_result_list.emplace(m_print_index, gcode);
		first_plate->set_print(print, gcode, m_print_index);
		m_print_index++;
	}
	first_plate->set_index(0);

	m_plate_count = 1;
	m_plate_cols = 1;
	m_current_plate = 0;

	select_plate(0);
	unprintable_plate.set_index(1);

	m_intialized = true;
}

void PartPlateList::update_plate_trans(int count)
{
    m_update_plate_mats_vbo = true;
    m_plate_trans.resize(count);
    int cols     = compute_colum_count(count);
    for (size_t i = 0; i < count; i++) {
        Vec2d pos          = compute_shape_position(i, cols);
        Vec3d plate_origin= Vec3d(pos.x(), pos.y(), 0);
        m_plate_trans[i].set_offset(plate_origin);
	}
    update_unselected_plate_trans(count);
}

void PartPlateList::update_unselected_plate_trans(int count) {
    if (count == 1) {
        m_unselected_plate_trans.clear();
        return;
	}
    m_update_unselected_plate_mats_vbo = true;
    m_unselected_plate_trans.resize(count - 1);
    int cols = compute_colum_count(count);
    int index = 0;
    for (size_t i = 0; i < count; i++) {
        if (i == m_current_plate) { continue; }
        Vec2d pos          = compute_shape_position(i, cols);
        Vec3d plate_origin = Vec3d(pos.x(), pos.y(), 0);
        m_unselected_plate_trans[index].set_offset(plate_origin);
        index++;
    }
}

void PartPlateList::generate_print_polygon(ExPolygon &print_polygon)
{
    auto compute_points = [&print_polygon](Vec2d &center, double radius, double start_angle, double stop_angle, int count) {
        double angle_steps;
        angle_steps = (stop_angle - start_angle) / (count - 1);
        for (int j = 0; j < count; j++) {
            double angle = start_angle + j * angle_steps;
            double x     = center(0) + ::cos(angle) * radius;
            double y     = center(1) + ::sin(angle) * radius;
            print_polygon.contour.append({scale_(x), scale_(y)});
        }
    };
    bool use_rect_grid = false;
    if (&wxGetApp() && wxGetApp().plater()) {
        auto pm       = wxGetApp().plater()->get_curr_printer_model();
        use_rect_grid = (pm && pm->use_rect_grid == "true") ? true : false;
    }
    int points_count = 8;
    if (m_shape.size() == 4 && !use_rect_grid) {
        // rectangle case
        for (int i = 0; i < 4; i++) {
            const Vec2d &p = m_shape[i];
            Vec2d        center;
            double       start_angle, stop_angle, radius_x, radius_y, radius;
            switch (i) {
            case 0:
                radius      = 8.f;
                center(0)   = p(0) + radius;
                center(1)   = p(1) + radius;
                start_angle = PI;
                stop_angle  = 1.5 * PI;
                compute_points(center, radius, start_angle, stop_angle, points_count);
                break;
            case 1: print_polygon.contour.append({scale_(p(0)), scale_(p(1))}); break;
            case 2:
                radius_x = (int) (p(0)) % 10;
                radius_y = (int) (p(1)) % 10;
                radius   = (radius_x > radius_y) ? radius_y : radius_x;
                if (radius < 5.0) radius = 5.f;
                center(0)   = p(0) - radius;
                center(1)   = p(1) - radius;
                start_angle = 0;
                stop_angle  = 0.5 * PI;
                compute_points(center, radius, start_angle, stop_angle, points_count);
                break;
            case 3:
                radius_x = (int) (p(0)) % 10;
                radius_y = (int) (p(1)) % 10;
                radius   = (radius_x > radius_y) ? radius_y : radius_x;
                if (radius < 5.0) radius = 5.f;
                center(0)   = p(0) + radius;
                center(1)   = p(1) - radius;
                start_angle = 0.5 * PI;
                stop_angle  = PI;
                compute_points(center, radius, start_angle, stop_angle, points_count);
                break;
            }
        }
    } else {
        for (const Vec2d &p : m_shape) {
			print_polygon.contour.append({scale_(p(0)), scale_(p(1))});
		}
    }
}

void PartPlateList::generate_exclude_polygon(ExPolygon &exclude_polygon)
{
    auto compute_exclude_points = [&exclude_polygon](Vec2d &center, double radius, double start_angle, double stop_angle, int count) {
        double angle_steps;
        angle_steps = (stop_angle - start_angle) / (count - 1);
        for (int j = 0; j < count; j++) {
            double angle = start_angle + j * angle_steps;
            double x     = center(0) + ::cos(angle) * radius;
            double y     = center(1) + ::sin(angle) * radius;
            exclude_polygon.contour.append({scale_(x), scale_(y)});
        }
    };

    int points_count = 8;
    if (m_exclude_areas.size() == 4) {
        // rectangle case
        for (int i = 0; i < 4; i++) {
            const Vec2d &p = m_exclude_areas[i];
            Vec2d        center;
            double       start_angle, stop_angle, radius;
            switch (i) {
            case 0:
                radius      = 8.f;
                center(0)   = p(0) + radius;
                center(1)   = p(1) + radius;
                start_angle = PI;
                stop_angle  = 1.5 * PI;
                compute_exclude_points(center, radius, start_angle, stop_angle, points_count);
                break;
            case 1: exclude_polygon.contour.append({scale_(p(0)), scale_(p(1))}); break;
            case 2:
                radius      = 3.f;
                center(0)   = p(0) - radius;
                center(1)   = p(1) - radius;
                start_angle = 0;
                stop_angle  = 0.5 * PI;
                compute_exclude_points(center, radius, start_angle, stop_angle, points_count);
                break;
            case 3: exclude_polygon.contour.append({scale_(p(0)), scale_(p(1))}); break;
            }
        }
    } else {
        for (const Vec2d &p : m_exclude_areas) {
			exclude_polygon.contour.append({scale_(p(0)), scale_(p(1))});
		}
    }
}

void PartPlateList::calc_triangles(const ExPolygon &poly)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_exclude_triangles(const ExPolygon &poly)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_triangles_from_polygon(const ExPolygon &poly, GLModel &render_model){} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_gridlines(const ExPolygon &poly, const BoundingBox &pp_bbox)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_vertex_for_number(int index, bool one_number, GLModel &gl_model)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_vertex_for_icons(int index, GLModel &gl_model)
{} /* WASM: çizim kodu kaldırıldı */

//compute the origin for printable plate with index i
Vec3d PartPlateList::compute_origin(int i, int cols)
{
	Vec3d origin;
	Vec2d pos = compute_shape_position(i, cols);
	origin    = Vec3d(pos.x(), pos.y(), 0);

	return origin;
}

//compute the origin for printable plate with index i using new width
Vec3d PartPlateList::compute_origin_using_new_size(int i, int new_width, int new_depth)
{
	Vec3d origin;
	int row, col;

	row = i / m_plate_cols;
	col = i % m_plate_cols;

	origin(0) = col * (new_width * (1. + LOGICAL_PART_PLATE_GAP));
	origin(1) = -row * (new_depth * (1. + LOGICAL_PART_PLATE_GAP));
	origin(2) = 0;

	return origin;
}


//compute the origin for printable plate with index i
Vec3d PartPlateList::compute_origin_for_unprintable()
{
	int max_count = m_plate_cols * m_plate_cols;
	if (m_plate_count == max_count)
		return compute_origin(max_count + m_plate_cols - 1, m_plate_cols + 1);
	else
		return compute_origin(m_plate_count, m_plate_cols);
}

//compute shape position
Vec2d PartPlateList::compute_shape_position(int index, int cols)
{
	Vec2d pos;
	int row, col;

	row = index / cols;
	col = index % cols;

	pos(0) = col * plate_stride_x();
	pos(1) = -row * plate_stride_y();

	return pos;
}

//generate icon textures
void PartPlateList::generate_icon_textures()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::release_icon_textures()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::set_default_wipe_tower_pos_for_plate(int plate_idx, bool init_pos, bool keep_existing)
{
    DynamicConfig &     proj_cfg     = wxGetApp().preset_bundle->project_config;
    ConfigOptionFloats *wipe_tower_x = proj_cfg.opt<ConfigOptionFloats>("wipe_tower_x");
    ConfigOptionFloats *wipe_tower_y = proj_cfg.opt<ConfigOptionFloats>("wipe_tower_y");
    // Guard against UB when values is empty: front() on an empty vector is undefined.
    wipe_tower_x->values.resize(m_plate_list.size(), wipe_tower_x->values.empty() ? 0.0 : wipe_tower_x->values.front());
    wipe_tower_y->values.resize(m_plate_list.size(), wipe_tower_y->values.empty() ? 0.0 : wipe_tower_y->values.front());

    // Resolve initial wipe tower position in one shot so x/y are never read uninitialised.
    // Each branch in the IIFE must return, guaranteeing both coordinates have a value.
    auto [x, y] = [&]() -> std::pair<float, float> {
        if (keep_existing && plate_idx >= 0 && plate_idx < (int)wipe_tower_x->values.size() && plate_idx < (int)wipe_tower_y->values.size())
            return { (float)wipe_tower_x->values[plate_idx], (float)wipe_tower_y->values[plate_idx] };

        auto printer_structure_opt = wxGetApp().preset_bundle->printers.get_edited_preset().config.option<ConfigOptionEnum<PrinterStructure>>("printer_structure");
        if (printer_structure_opt && printer_structure_opt->value == PrinterStructure::psI3)
            return { I3_WIPE_TOWER_DEFAULT_X_POS, I3_WIPE_TOWER_DEFAULT_Y_POS };
        // Default position aligns with print config (left top).
        return { WIPE_TOWER_DEFAULT_X_POS, WIPE_TOWER_DEFAULT_Y_POS };
    }();

    std::string printer_type = wxGetApp().preset_bundle->printers.get_edited_preset().get_printer_type(wxGetApp().preset_bundle);

    // Note: printer_type == "N9" and printer_structure_opt->value == PrinterStructure::psI3 can both be true
    if (printer_type == "N9") {
        y = N9_WIPE_TOWER_DEFAULT_Y_POS;
    }
    const float margin     = WIPE_TOWER_MARGIN;
    PartPlate* part_plate = get_plate(plate_idx);
    Vec3d plate_origin = part_plate->get_origin();
    BoundingBoxf3  plate_bbox = part_plate->get_bounding_box();
    BoundingBoxf  plate_bbox_2d(Vec2d(plate_bbox.min(0), plate_bbox.min(1)), Vec2d(plate_bbox.max(0), plate_bbox.max(1)));
    const std::vector<Pointfs> &extruder_areas = part_plate->get_extruder_areas();
    for (Pointfs points : extruder_areas) {
        BoundingBoxf bboxf(points);
        plate_bbox_2d.min = plate_bbox_2d.min(0) >= bboxf.min(0) ? plate_bbox_2d.min : bboxf.min;
        plate_bbox_2d.max = plate_bbox_2d.max(0) <= bboxf.max(0) ? plate_bbox_2d.max : bboxf.max;
    }

    coordf_t plate_bbox_x_min_local_coord = plate_bbox_2d.min(0) - plate_origin(0);
    coordf_t plate_bbox_x_max_local_coord = plate_bbox_2d.max(0) - plate_origin(0);
    coordf_t plate_bbox_y_max_local_coord = plate_bbox_2d.max(1) - plate_origin(1);

    std::vector<int>   filament_maps = part_plate->get_real_filament_maps(proj_cfg);
    std::vector<int> f_volume_maps = part_plate->get_filament_volume_maps();
    if (f_volume_maps.empty()) {
        f_volume_maps = wxGetApp().preset_bundle->get_default_nozzle_volume_types_for_filaments(filament_maps);
    }
    DynamicPrintConfig full_config   = wxGetApp().preset_bundle->full_config(false, filament_maps, f_volume_maps);
    const DynamicPrintConfig &print_cfg = wxGetApp().preset_bundle->prints.get_edited_preset().config;
    float w = dynamic_cast<const ConfigOptionFloat*>(print_cfg.option("prime_tower_width"))->value;
    std::vector<double> v = dynamic_cast<const ConfigOptionFloats*>(full_config.option("filament_prime_volume"))->values;
	if (full_config.option<ConfigOptionEnum<PrimeVolumeMode>>("prime_volume_mode")->value == pvmSaving) {
		for (auto& val : v)
			val = 15.f;
	}
    bool enable_wrapping = dynamic_cast<const ConfigOptionBool*>(full_config.option("enable_wrapping_detection"))->value;
    int nozzle_nums = wxGetApp().preset_bundle->get_printer_extruder_count();
    double wipe_vol = get_max_element(v);
    Vec3d wipe_tower_size = part_plate->estimate_wipe_tower_size(print_cfg, w, wipe_vol, nozzle_nums, init_pos ? 2 : 0, false, enable_wrapping);

    if (!init_pos && (is_approx(wipe_tower_size(0), 0.0) || is_approx(wipe_tower_size(1), 0.0))) {
        wipe_tower_size = part_plate->estimate_wipe_tower_size(print_cfg, w, wipe_vol, nozzle_nums, 2, false, enable_wrapping);
    }

    // update for wipe tower position
    {
        bool need_update = false;
        if (x + margin + wipe_tower_size(0) > plate_bbox_x_max_local_coord) {
            x = plate_bbox_x_max_local_coord - wipe_tower_size(0) - margin;
        } else if (x < margin + plate_bbox_x_min_local_coord) {
            x = margin + plate_bbox_x_min_local_coord;
        }

        if (y + margin + wipe_tower_size(1) > plate_bbox_y_max_local_coord) {
            y = plate_bbox_y_max_local_coord - wipe_tower_size(1) - margin;
        } else if (y < margin) {
            y = margin;
        }
    }

    ConfigOptionFloat wt_x_opt(x);
    ConfigOptionFloat wt_y_opt(y);

    dynamic_cast<ConfigOptionFloats *>(proj_cfg.option("wipe_tower_x"))->set_at(&wt_x_opt, plate_idx, 0);
    dynamic_cast<ConfigOptionFloats *>(proj_cfg.option("wipe_tower_y"))->set_at(&wt_y_opt, plate_idx, 0);
}

//this may be happened after machine changed
void PartPlateList::reset_size(int width, int depth, int height, bool reload_objects, bool update_shapes)
{
	Vec3d origin1, origin2;

	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":before size: plate_width %1%, plate_depth %2%, plate_height %3%") % m_plate_width % m_plate_depth % m_plate_height;
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":after size: plate_width %1%, plate_depth %2%, plate_height %3%") % width % depth % height;
	if ((m_plate_width != width) || (m_plate_depth != depth) || (m_plate_height != height))
	{
		m_plate_width = width;
		m_plate_depth = depth;
		m_plate_height = height;
		update_all_plates_pos_and_size(false, false, true);
		if (update_shapes) {
			set_shapes(m_shape, m_exclude_areas, m_wrapping_exclude_areas, m_extruder_areas, m_extruder_heights, m_logo_texture_filename, m_height_to_lid, m_height_to_rod);
		}
		if (reload_objects)
			reload_all_objects();
		else
			clear(false, false, false, -1);
	}

	return;
}

//clear all the instances in the plate, but keep the plates
void PartPlateList::clear(bool delete_plates, bool release_print_list, bool except_locked, int plate_index)
{
	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		PartPlate* plate = m_plate_list[i];
		assert(plate != NULL);

		if (except_locked && plate->is_locked())
			plate->clear(false);
		else if ((plate_index != -1) && (plate_index != i))
			plate->clear(false);
		else
			plate->clear();
		if (delete_plates)
			delete plate;
	}

	if (delete_plates)
	{
		//also delete print related to the plate
		m_plate_list.clear();
		m_current_plate = 0;
	}

	if (release_print_list)
	{
		for (std::map<int, PrintBase*>::iterator it = m_print_list.begin(); it != m_print_list.end(); ++it)
		{
			PrintBase* print = it->second;
			assert(print != NULL);

			delete print;
		}
		m_print_list.clear();
		for (std::map<int, GCodeResult*>::iterator it = m_gcode_result_list.begin(); it != m_gcode_result_list.end(); ++it)
		{
			GCodeResult* gcode = it->second;
			assert(gcode != NULL);

			delete gcode;
		}
		m_gcode_result_list.clear();
	}

	// Preserve virtual plate snapshot on in-place rebuilds; only wipe on full delete.
	if (delete_plates)
		unprintable_plate.clear();
}

//clear all the instances in the plate, and delete the plates, only keep the first default plate
void PartPlateList::reset(bool do_init)
{
	clear(true, false);

	//m_plate_list.clear();

	if (do_init) {
		init();
		m_plate_list[0]->set_filament_count(m_filament_count);
	}

	return;
}

//reset partplate to init states
void PartPlateList::reinit()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::set_bed3d(Bed3D *_bed3d) {} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::update_plates()
{} /* WASM: çizim kodu kaldırıldı */

/*basic plate operations*/
//create an empty plate, and return its index
//these model instances which are not in any plates should not be affected also
int PartPlateList::create_plate(bool adjust_position)
{
	PartPlate* plate = NULL;
	Vec3d origin;
	int new_index;

	new_index = m_plate_list.size();
	if (new_index >= MAX_PLATES_COUNT)
		return -1;
	int cols = compute_colum_count(new_index + 1);
	int old_cols = compute_colum_count(new_index);

	origin = compute_origin(new_index, cols);
	plate = new PartPlate(this, origin, m_plate_width, m_plate_depth, m_plate_height, m_plater, m_model, true, printer_technology);
	assert(plate != NULL);

	if (printer_technology == ptFFF)
	{
		Print* print = new Print();
		GCodeResult* gcode = new GCodeResult();
		m_print_list.emplace(m_print_index, print);
		m_gcode_result_list.emplace(m_print_index, gcode);
		plate->set_print(print, gcode, m_print_index);
		m_print_index++;
	}

	plate->set_filament_count(m_filament_count);

	plate->set_index(new_index);
	Vec2d pos = compute_shape_position(new_index, cols);
	plate->set_shape(m_shape, m_exclude_areas, m_extruder_areas, m_extruder_heights, pos, m_height_to_lid, m_height_to_rod);
	m_plate_list.emplace_back(plate);
	update_plate_cols();
	if (old_cols != cols)
	{
		BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":old_cols %1% -> new_cols %2%") % old_cols % cols;
		//update the origin of each plate
		update_all_plates_pos_and_size(adjust_position, false);
		set_shapes(m_shape, m_exclude_areas, m_wrapping_exclude_areas, m_extruder_areas, m_extruder_heights, m_logo_texture_filename, m_height_to_lid, m_height_to_rod);

		if (m_plater) {
			Vec2d pos = compute_shape_position(m_current_plate, cols);
			m_plater->set_bed_position(pos);
		}
	}
	else
	{
		BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": the same cols %1%") % old_cols;
		Vec3d origin2 = compute_origin_for_unprintable();
		// do_clear=false: relocating must not wipe inst_set used by reload_all_objects.
		unprintable_plate.set_pos_and_size(origin2, m_plate_width, m_plate_depth, m_plate_height, false, false);

		//update bounding_boxes
		calc_bounding_boxes();
	}

	// update wipe tower config
	if (m_plater) {
		// In GUI mode
        set_default_wipe_tower_pos_for_plate(new_index, true);
	}

	unprintable_plate.set_index(new_index+1);

	//reload all objects here
	if (adjust_position)
		construct_objects_list_for_new_plate(new_index);

	if (m_plater) {
		// In GUI mode
		wxGetApp().obj_list()->on_plate_added(plate);
	}

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":created a new plate %1%") % new_index;
	return new_index;
}

//destroy print's objects and results
int PartPlateList::destroy_print(int print_index)
{
	int result = 0;

	if (print_index >= 0)
	{
		std::map<int, PrintBase*>::iterator it = m_print_list.find(print_index);
		if (it != m_print_list.end())
		{
			BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":delete Print %1% for print_index %2%") % it->second % print_index;
			delete it->second;
			m_print_list.erase(it);
		}
		else
		{
			BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":can not find Print for print_index %1%") % print_index;
			result = -1;
		}
		std::map<int, GCodeResult*>::iterator it2 = m_gcode_result_list.find(print_index);
		if (it2 != m_gcode_result_list.end())
		{
			BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":delete GCodeResult %1% for print_index %2%") % it2->second % print_index;
			delete it2->second;
			m_gcode_result_list.erase(it2);
		}
		else
		{
			BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":can not find GCodeResult for print_index %1%") % print_index;
			result = -1;
		}
	}

	return result;
}

void PartPlateList::add_plate() {} /* WASM: çizim kodu kaldırıldı */

//delete a plate by index
//keep its instance at origin position and add them into next plate if have
//update the plate index and position after it
int PartPlateList::delete_plate(int index)
{
	int ret = 0;
	PartPlate* plate = NULL;

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":delete plate %1%, count %2%") % index % m_plate_list.size();
	if (index >= m_plate_list.size())
	{
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":can not find plate");
		return -1;
	}
	if (m_plate_list.size() <= 1)
	{
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":only one plate left, can not delete");
		return -1;
	}

	plate = m_plate_list[index];
	if (index != plate->get_index())
	{
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":plate %1%, has an invalid index %2%") % index % plate->get_index();
		return -1;
	}

	if (m_plater) {
		// In GUI mode
		// BBS: add wipe tower logic
		DynamicConfig& proj_cfg = wxGetApp().preset_bundle->project_config;
		ConfigOptionFloats* wipe_tower_x = proj_cfg.opt<ConfigOptionFloats>("wipe_tower_x");
		ConfigOptionFloats* wipe_tower_y = proj_cfg.opt<ConfigOptionFloats>("wipe_tower_y");
		// wipe_tower_x and wip_tower_y may be less than plate count in the following case:
		// 1. wipe_tower is enabled after creating new plates
		// 2. wipe tower is not enabled
		if (index < wipe_tower_x->values.size())
			wipe_tower_x->values.erase(wipe_tower_x->values.begin() + index);
		if (index < wipe_tower_y->values.size())
			wipe_tower_y->values.erase(wipe_tower_y->values.begin() + index);
	}

	int cols = compute_colum_count(m_plate_list.size() - 1);
	int old_cols = compute_colum_count(m_plate_list.size());

	m_plate_list.erase(m_plate_list.begin() + index);
	update_plate_cols();
	//update this plate
	//move this plate's instance to the end
	Vec3d current_origin;
	current_origin = compute_origin_for_unprintable();
	plate->set_pos_and_size(current_origin, m_plate_width, m_plate_depth, m_plate_height, true);

	//update the plates after it
	for (unsigned int i = index; i < (unsigned int)m_plate_list.size(); ++i)
	{
		PartPlate* plate = m_plate_list[i];
		assert(plate != NULL);

		plate->set_index(i);
		Vec3d origin = compute_origin(i, m_plate_cols);
		plate->set_pos_and_size(origin, m_plate_width, m_plate_depth, m_plate_height, true);

		//update render shapes
		Vec2d pos = compute_shape_position(i, m_plate_cols);
		plate->set_shape(m_shape, m_exclude_areas, m_extruder_areas, m_extruder_heights, pos, m_height_to_lid, m_height_to_rod);
	}

	//update current_plate if delete current
	if (m_current_plate == index && index == 0) {
		select_plate(0);
	}
	else if (m_current_plate >= index) {
		select_plate(m_current_plate - 1);
	}
	else {
		//delete the plate behind current, just need to update the position of Bed3D
		Vec2d pos = compute_shape_position(m_current_plate, m_plate_cols);
		if (m_plater)
			m_plater->set_bed_position(pos);
	}

	unprintable_plate.set_index(m_plate_list.size());

	if (old_cols != cols)
	{
		//update the origin of each plate
		update_all_plates_pos_and_size();
		set_shapes(m_shape, m_exclude_areas, m_wrapping_exclude_areas, m_extruder_areas, m_extruder_heights, m_logo_texture_filename, m_height_to_lid, m_height_to_rod);
	}
	else
	{
		//update the position of the unprintable plate
		Vec3d origin2 = compute_origin_for_unprintable();
		unprintable_plate.set_pos_and_size(origin2, m_plate_width, m_plate_depth, m_plate_height, true);

		//update bounding_boxes
		calc_bounding_boxes();
	}

	plate->move_instances_to(*(m_plate_list[m_plate_list.size()-1]), unprintable_plate);
	//destroy the print object
	int print_index;
	plate->get_print(nullptr, nullptr, &print_index);
	destroy_print(print_index);

	delete plate;
    update_plate_trans(get_plate_count());
    // FIX: context of BackgroundSliceProcess and gcode preview need to be updated before ObjectList::reload_all_plates().
#if 0
	if (m_plater != nullptr) {
		// In GUI mode
		wxGetApp().obj_list()->reload_all_plates();
	}
#endif
	return ret;
}

void PartPlateList::delete_selected_plate()
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlateList::check_all_plate_local_bed_type(const std::vector<BedType> &cur_bed_types)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//get a plate pointer by index
PartPlate* PartPlateList::get_plate(int index)
{
	PartPlate* plate = NULL;

	if (index >= m_plate_list.size() || index < 0)
	{
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":can not find index %1%, size %2%") % index % m_plate_list.size();
		return NULL;
	}

	plate = m_plate_list[index];
	assert(plate != NULL);

	return plate;
}

PartPlate* PartPlateList::get_selected_plate()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::vector<PartPlate*> PartPlateList::get_nonempty_plate_list()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

std::vector<const GCodeProcessorResult*> PartPlateList::get_nonempty_plates_slice_results() { return {}; } /* WASM: çizim kodu kaldırıldı */

std::set<int> PartPlateList::get_extruders(bool conside_custom_gcode) const
{
    int plate_count = get_plate_count();
    std::set<int> extruder_ids;

    for (size_t i = 0; i < plate_count; i++) {
        auto plate_extruders = m_plate_list[i]->get_extruders(conside_custom_gcode);
        extruder_ids.insert(plate_extruders.begin(), plate_extruders.end());
    }

    return extruder_ids;
}


//select plate
int PartPlateList::select_plate(int index)
{
	const std::lock_guard<std::mutex> local_lock(m_plates_mutex);
	if (m_plate_list.empty() || index >= m_plate_list.size()) {
		return -1;
	}

	// BBS: erase unnecessary snapshot
	if (get_curr_plate_index() != index && m_intialized) {
		if (m_plater)
			m_plater->take_snapshot("select partplate!");
	}

	std::vector<PartPlate *>::iterator it = m_plate_list.begin();
	for (it = m_plate_list.begin(); it != m_plate_list.end(); it++) {
		(*it)->set_unselected();
	}

	m_current_plate = index;
	m_plate_list[m_current_plate]->set_selected();

    update_plate_trans(get_plate_count());
	//BBS
	if(m_model)
		m_model->curr_plate_index = index;

	//BBS update bed origin
	if (m_intialized && m_plater) {
		Vec2d pos = compute_shape_position(index, m_plate_cols);
        m_plater->set_bed_position(pos);
		//wxQueueEvent(m_plater, new SimpleEvent(EVT_GLCANVAS_PLATE_SELECT));
	}

	return 0;
}

void PartPlateList::set_hover_id(int id)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::reset_hover_id()
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlateList::intersects(const BoundingBoxf3& bb)
{
	bool result = false;
	std::vector<PartPlate*>::iterator it = m_plate_list.begin();
	for (it = m_plate_list.begin(); it != m_plate_list.end(); it++) {
		if ((*it)->intersects(bb)) {
			result = true;
		}
	}
	return result;
}

bool PartPlateList::contains(const BoundingBoxf3& bb)
{
	bool result = false;
	std::vector<PartPlate*>::iterator it = m_plate_list.begin();
	for (it = m_plate_list.begin(); it != m_plate_list.end(); it++) {
		if ((*it)->contains(bb)) {
			result = true;
		}
	}
	return result;
}

double PartPlateList::plate_stride_x()
{
	//const auto plate_shape = Slic3r::Polygon::new_scale(m_shape);
	//double plate_width = plate_shape.bounding_box().size().x();
	//return unscaled<double>((1. + LOGICAL_PART_PLATE_GAP) * plate_width);
	return m_plate_width * (1. + LOGICAL_PART_PLATE_GAP);
}

double PartPlateList::plate_stride_y()
{
	//const auto plate_shape = Slic3r::Polygon::new_scale(m_shape);
	//double plate_depth = plate_shape.bounding_box().size().y();
	//return unscaled<double>((1. + LOGICAL_PART_PLATE_GAP) * plate_depth);
	return m_plate_depth * (1. + LOGICAL_PART_PLATE_GAP);
}

//get the plate counts, not including the invalid plate
int PartPlateList::get_plate_count() const
{
	int ret = 0;

	ret = m_plate_list.size();

	return ret;
}

//update the plate cols due to plate count change
void PartPlateList::update_plate_cols()
{
	m_plate_count = m_plate_list.size();

	m_plate_cols = compute_colum_count(m_plate_count);
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":m_plate_count %1%, m_plate_cols change to %2%") % m_plate_count % m_plate_cols;
	return;
}

void PartPlateList::update_all_plates_pos_and_size(bool adjust_position, bool with_unprintable_move, bool switch_plate_type, bool do_clear)
{
	Vec3d origin1, origin2;
	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		PartPlate* plate = m_plate_list[i];
		assert(plate != NULL);

		//compute origin1 for PartPlate
		origin1 = compute_origin(i, m_plate_cols);
		plate->set_pos_and_size(origin1, m_plate_width, m_plate_depth, m_plate_height, adjust_position, do_clear);
	}

	origin2 = compute_origin_for_unprintable();
	// do_clear=false: only reload_all_objects is allowed to rebuild inst_set.
	unprintable_plate.set_pos_and_size(origin2, m_plate_width, m_plate_depth, m_plate_height, with_unprintable_move, false);
}

//move the plate to position index
int PartPlateList::move_plate_to_index(int old_index, int new_index)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//lock plate
int PartPlateList::lock_plate(int index, bool state)
{
	int ret = 0;
	PartPlate* plate = NULL;

	plate = get_plate(index);
	if (!plate)
	{
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << boost::format(":can not get plate for index %1%, size %2%") % index % m_plate_list.size();
		return -1;
	}
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":lock plate %1%, to state %2%") % index % state;

	plate->lock(state);

	return ret;
}

//find plate by print index, return -1 if not found
int PartPlateList::find_plate_by_print_index(int print_index)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/*instance related operations*/
//find instance in which plate, return -1 when not found
//this function only judges whether it is intersect with plate
int PartPlateList::find_instance(int obj_id, int instance_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

/*instance related operations*/
//find instance in which plate, return -1 when not found
//this function only judges whether it is intersect with plate
int PartPlateList::find_instance(BoundingBoxf3& bounding_box)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//this function not only judges whether it is intersect with plate, but also judges whether it is fully included in plate
//returns -1 when can not find any plate
int PartPlateList::find_instance_belongs(int obj_id, int instance_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//notify instance's update, need to refresh the instance in plates
//newly added or modified
int PartPlateList::notify_instance_update(int obj_id, int instance_id, bool is_new)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//notify instance is removed
int PartPlateList::notify_instance_removed(int obj_id, int instance_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//add instance to special plate, need to remove from the original plate
//called from the right-mouse menu when a instance selected
int PartPlateList::add_to_plate(int obj_id, int instance_id, int plate_id)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//reload all objects
int PartPlateList::reload_all_objects(bool except_locked, int plate_index)
{
	int ret = 0;
	unsigned int i, j, k;

	// Snapshot virtual-plate ownership before clear(); otherwise real plates
	// overlapping the old virtual area could steal the parked instances.
	std::set<std::pair<int, int>> sticky_virtual = unprintable_plate.get_obj_and_inst_set();

	clear(false, false, except_locked, plate_index);

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": m_model->objects.size() is %1%") % m_model->objects.size();
	//try to find a new plate
	for (i = 0; i < (unsigned int)m_model->objects.size(); ++i)
	{
		ModelObject* object = m_model->objects[i];
		for (j = 0; j < (unsigned int)object->instances.size(); ++j)
		{
			ModelInstance* instance = object->instances[j];
			BoundingBoxf3 boundingbox = object->instance_convex_hull_bounding_box(j);

			// Re-park sticky-virtual instances first; re-snap geometry to the
			// current virtual centre so a shifted origin can't push them into
			// a brand-new real plate's bbox.
			if (sticky_virtual.count(std::make_pair((int)i, (int)j)))
			{
				Vec3d center = unprintable_plate.get_center_origin();
				center.z() = instance->get_transformation().get_offset(Z);
				instance->set_offset(center);
				object->invalidate_bounding_box();
				BoundingBoxf3 new_bbox = object->instance_convex_hull_bounding_box(j);
				unprintable_plate.add_instance(i, j, false, &new_bbox);
				continue;
			}

			for (k = 0; k < (unsigned int)m_plate_list.size(); ++k)
			{
				PartPlate* plate = m_plate_list[k];
				assert(plate != NULL);

				if (plate->intersect_instance(i, j, &boundingbox))
				{
					//found a new plate, add it to plate
					plate->add_instance(i, j, false, &boundingbox);
					BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": found plate_id %1%, for obj_id %2%, instance_id %3%") % k % i % j;

					//need to judge whether this instance has an outer part
					/*if (plate->check_outside(i, j))
					{
						plate->m_ready_for_slice = false;
					}*/
					break;
				}
			}

			if ((k == m_plate_list.size()) && (unprintable_plate.intersect_instance(i, j, &boundingbox)))
			{
				//found in unprintable plate, add it to plate
				unprintable_plate.add_instance(i, j, false, &boundingbox);
				BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": found in unprintable plate, obj_id %1%, instance_id %2%") % i % j;
			}
		}

	}

	return ret;
}

//reload objects for newly created plate
int PartPlateList::construct_objects_list_for_new_plate(int plate_index)
{
	int ret = 0;
	unsigned int i, j, k;
	PartPlate* new_plate = m_plate_list[plate_index];
	bool already_included;

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": m_model->objects.size() is %1%") % m_model->objects.size();
	// Snapshot virtual-plate ownership before clear(); see reload_all_objects.
	std::set<std::pair<int, int>> sticky_virtual = unprintable_plate.get_obj_and_inst_set();
	unprintable_plate.clear();
	//try to find a new plate
	for (i = 0; i < (unsigned int)m_model->objects.size(); ++i)
	{
		ModelObject* object = m_model->objects[i];
		for (j = 0; j < (unsigned int)object->instances.size(); ++j)
		{
			ModelInstance* instance = object->instances[j];
			already_included = false;

			for (k = 0; k < (unsigned int)plate_index; ++k)
			{
				PartPlate* plate = m_plate_list[k];
				if (plate->contain_instance(i, j))
				{
					already_included = true;
					break;
				}
			}

			if (already_included)
				continue;

			BoundingBoxf3 boundingbox = object->instance_convex_hull_bounding_box(j);

			// Re-park sticky-virtual instances first; re-snap to the virtual centre.
			if (sticky_virtual.count(std::make_pair((int)i, (int)j)))
			{
				Vec3d center = unprintable_plate.get_center_origin();
				center.z() = instance->get_transformation().get_offset(Z);
				instance->set_offset(center);
				object->invalidate_bounding_box();
				BoundingBoxf3 new_bbox = object->instance_convex_hull_bounding_box(j);
				unprintable_plate.add_instance(i, j, false, &new_bbox);
				continue;
			}

			if (new_plate->intersect_instance(i, j, &boundingbox))
			{
				//found a new plate, add it to plate
				ret |= new_plate->add_instance(i, j, false, &boundingbox);
				BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": added to plate_id %1%, for obj_id %2%, instance_id %3%") % plate_index % i % j;

				continue;
			}

			if ( (unprintable_plate.intersect_instance(i, j, &boundingbox)))
			{
				//found in unprintable plate, add it to plate
				unprintable_plate.add_instance(i, j, false, &boundingbox);
				BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": found in unprintable plate, obj_id %1%, instance_id %2%") % i % j;
			}
		}
	}

	return ret;
}

std::vector<Vec2d> PartPlateList::get_plate_wrapping_detection_area()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//compute the plate index
int PartPlateList::compute_plate_index(arrangement::ArrangePolygon& arrange_polygon)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//preprocess a arrangement::ArrangePolygon, return true if it is in a locked plate
bool PartPlateList::preprocess_arrange_polygon(int obj_index, int instance_index, arrangement::ArrangePolygon& arrange_polygon, bool selected)
{
	bool locked = false;
	int lockplate_cnt = 0;

	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		if (m_plate_list[i]->contain_instance(obj_index, instance_index))
		{
			if (m_plate_list[i]->is_locked())
			{
				locked = true;
				arrange_polygon.bed_idx = i;
				arrange_polygon.row = i / m_plate_cols;
				arrange_polygon.col = i % m_plate_cols;
				arrange_polygon.translation(X) -= scaled<double>(plate_stride_x() * arrange_polygon.col);
				arrange_polygon.translation(Y) += scaled<double>(plate_stride_y() * arrange_polygon.row);
			}
			else
			{
				if (!selected)
				{
					//will be treated as fixeditem later
					arrange_polygon.bed_idx = i - lockplate_cnt;
					arrange_polygon.row = i / m_plate_cols;
					arrange_polygon.col = i % m_plate_cols;
					arrange_polygon.translation(X) -= scaled<double>(plate_stride_x() * arrange_polygon.col);
					arrange_polygon.translation(Y) += scaled<double>(plate_stride_y() * arrange_polygon.row);
				}
			}
			BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": obj_id %1% name %7% instance_id %2% already in plate %3%, locked %4%, row %5%, col %6%\n") % obj_index % instance_index % i % locked % arrange_polygon.row % arrange_polygon.col % arrange_polygon.name;
			return locked;
		}
		if (m_plate_list[i]->is_locked())
			lockplate_cnt++;
	}
	//not be contained by any plates
	if (!selected)
		arrange_polygon.bed_idx = PartPlateList::MAX_PLATES_COUNT;

	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": not in any plates, bed_idx %1%, translation(x) %2%, (y) %3%") % arrange_polygon.bed_idx % unscale<double>(arrange_polygon.translation(X)) % unscale<double>(arrange_polygon.translation(Y));

	return locked;
}

//preprocess a arrangement::ArrangePolygon, return true if it is not in current plate
bool PartPlateList::preprocess_arrange_polygon_other_locked(int obj_index, int instance_index, arrangement::ArrangePolygon& arrange_polygon, bool selected)
{
	bool locked = false;

	if (selected)
	{
		//arrange_polygon.translation(X) -= scaled<double>(plate_stride_x() * m_current_plate);
	}
	else
	{
		locked = true;
		for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
		{
			if (m_plate_list[i]->contain_instance(obj_index, instance_index))
			{
				arrange_polygon.bed_idx = i;
				arrange_polygon.row = i / m_plate_cols;
				arrange_polygon.col = i % m_plate_cols;
				arrange_polygon.translation(X) -= scaled<double>(plate_stride_x() * arrange_polygon.col);
				arrange_polygon.translation(Y) += scaled<double>(plate_stride_y() * arrange_polygon.row);
				//BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": obj_id %1% instance_id %2% in plate %3%, locked %4%, row %5%, col %6%\n") % obj_index % instance_index % i % locked % arrange_polygon.row % arrange_polygon.col;
				return locked;
			}
		}
		arrange_polygon.bed_idx = PartPlateList::MAX_PLATES_COUNT;
	}
	return locked;
}

bool PartPlateList::preprocess_exclude_areas(arrangement::ArrangePolygons &unselected, bool enable_wrapping_detect, int num_plates, float inflation)
{
	bool added = false;

	// wrapping detection area
    if (enable_wrapping_detect)
	{
        if (!m_wrapping_exclude_areas.empty())
		{
			Polygon ap{};
            for (const Vec2d &p : m_wrapping_exclude_areas)
			{
                ap.append({scale_(p(0)), scale_(p(1))});
            }

			for(int j = 0; j < num_plates; j++)
			{
				arrangement::ArrangePolygon ret;
				ret.poly.contour = ap;
				ret.translation  = Vec2crd(0, 0);
				ret.rotation     = 0.0f;
				ret.is_virt_object = true;
				ret.bed_idx      = j;
				ret.height      = 1;
				ret.name = "WrappingRegion";
				ret.inflation = inflation;

				unselected.emplace_back(std::move(ret));
			}
		}
		added = true;
	}

	// excluded area
	if (m_exclude_areas.size() > 0)
	{
		//has exclude areas
		PartPlate *plate = m_plate_list[0];

		for (int index = 0; index < plate->m_exclude_bounding_box.size(); index ++)
		{
			Polygon ap({
				{scaled(plate->m_exclude_bounding_box[index].min.x()), scaled(plate->m_exclude_bounding_box[index].min.y())},
				{scaled(plate->m_exclude_bounding_box[index].max.x()), scaled(plate->m_exclude_bounding_box[index].min.y())},
				{scaled(plate->m_exclude_bounding_box[index].max.x()), scaled(plate->m_exclude_bounding_box[index].max.y())},
				{scaled(plate->m_exclude_bounding_box[index].min.x()), scaled(plate->m_exclude_bounding_box[index].max.y())}
				});

			for (int j = 0; j < num_plates; j++)
			{
				arrangement::ArrangePolygon ret;
				ret.poly.contour = ap;
				ret.translation  = Vec2crd(0, 0);
				ret.rotation     = 0.0f;
				ret.is_virt_object = true;
				ret.bed_idx      = j;
				ret.height      = 1;
				ret.name = "ExcludedRegion" + std::to_string(index);
				ret.inflation = inflation;

				unselected.emplace_back(std::move(ret));
			}
			added = true;
		}
	}

	return added;
}

bool PartPlateList::preprocess_nonprefered_areas(arrangement::ArrangePolygons& regions, int num_plates, float inflation)
{
	bool added = false;

	std::vector<BoundingBoxf> nonprefered_regions;
	nonprefered_regions.emplace_back(Vec2d{ 18,0 }, Vec2d{ 240,15 }); // new extrusion & hand-eye calibration region

	//has exclude areas
	PartPlate* plate = m_plate_list[0];
	for (int index = 0; index < nonprefered_regions.size(); index++)
	{
		Polygon ap = scaled(nonprefered_regions[index]).polygon();
		for (int j = 0; j < num_plates; j++)
		{
			arrangement::ArrangePolygon ret;
			ret.poly.contour = ap;
			ret.translation = Vec2crd(0, 0);
			ret.rotation = 0.0f;
			ret.is_virt_object = true;
            ret.is_extrusion_cali_object = true;
			ret.bed_idx = j;
			ret.height = 1;
			ret.name = "NonpreferedRegion" + std::to_string(index);
			ret.inflation = inflation;

			regions.emplace_back(std::move(ret));
		}
		added = true;
	}
	return added;
}


//postprocess an arrangement::ArrangePolygon's bed index
void PartPlateList::postprocess_bed_index_for_selected(arrangement::ArrangePolygon& arrange_polygon)
{
	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": bed_idx %1%, locked_plate %2%, translation(x) %3%, (y) %4%") % arrange_polygon.bed_idx % arrange_polygon.locked_plate % unscale<double>(arrange_polygon.translation(X)) % unscale<double>(arrange_polygon.translation(Y));

	if (arrange_polygon.bed_idx == -1)
	{
		//outarea for large object, can not process here for the plate number maybe increased later
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(": can not be arranged inside plate!");
		return;
	}

	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		if (m_plate_list[i]->is_locked())
		{
			BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": found locked_plate %1%, increate index by 1") % i;
			//arrange_polygon.translation(X) += scaled<double>(plate_stride_x());
			arrange_polygon.bed_idx += 1;
			//offset_x += scaled<double>(plate_stride_x());
		}
		else
		{
			//judge whether it is at the left side of the plate border
			if (arrange_polygon.bed_idx <= i)
			{
				BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":found in plate_index %1%, bed_idx %2%") % i % arrange_polygon.bed_idx;
				return;
			}
		}
	}

	//create a new plate which can hold this arrange_polygon
	int plate_index = create_plate(false);

	while (plate_index != -1)
	{
		if (arrange_polygon.bed_idx <= plate_index)
		{
			BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(":new plate_index %1%, matches bed_idx %2%") % plate_index % arrange_polygon.bed_idx;
			break;
		}

		plate_index = create_plate(false);
	}

	return;
}

//postprocess an arrangement::ArrangePolygon's bed index
void PartPlateList::postprocess_bed_index_for_unselected(arrangement::ArrangePolygon& arrange_polygon)
{} /* WASM: çizim kodu kaldırıldı */

//postprocess an arrangement::ArrangePolygon, other instances are under locked states
void PartPlateList::postprocess_bed_index_for_current_plate(arrangement::ArrangePolygon& arrange_polygon)
{
	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": bed_idx %1%, locked_plate %2%, translation(x) %3%, (y) %4%") % arrange_polygon.bed_idx % arrange_polygon.locked_plate % unscale<double>(arrange_polygon.translation(X)) % unscale<double>(arrange_polygon.translation(Y));

	if (arrange_polygon.bed_idx == -1)
	{
		//outarea for large object
		BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(": can not be arranged inside plate!");
	}
	else if (arrange_polygon.bed_idx == 0)
		arrange_polygon.bed_idx += m_current_plate;
	else
		arrange_polygon.bed_idx = m_plate_list.size();

	return;
}

//postprocess an arrangement::ArrangePolygon
void PartPlateList::postprocess_arrange_polygon(arrangement::ArrangePolygon& arrange_polygon, bool selected)
{
	BOOST_LOG_TRIVIAL(debug) << __FUNCTION__ << boost::format(": bed_idx %1%, selected %2%, translation(x) %3%, (y) %4%") % arrange_polygon.bed_idx % selected % unscale<double>(arrange_polygon.translation(X)) % unscale<double>(arrange_polygon.translation(Y));

	if ((selected) || (arrange_polygon.bed_idx != PartPlateList::MAX_PLATES_COUNT))
	{
		if (arrange_polygon.bed_idx == -1)
		{
			// outarea for large object
			arrange_polygon.bed_idx = m_plate_list.size();
			BoundingBox apbox = get_extents(arrange_polygon.transformed_poly());  // the item may have been rotated
			auto        apbox_size = apbox.size();

			arrange_polygon.translation(X) = 0.5 * apbox_size[0];
			arrange_polygon.translation(Y) = scaled<double>(static_cast<double>(m_plate_depth)) - 0.5 * apbox_size[1];
		}

		arrange_polygon.row = arrange_polygon.bed_idx / m_plate_cols;
		arrange_polygon.col = arrange_polygon.bed_idx % m_plate_cols;
		arrange_polygon.translation(X) += scaled<double>(plate_stride_x() * arrange_polygon.col);
		arrange_polygon.translation(Y) -= scaled<double>(plate_stride_y() * arrange_polygon.row);
	}

	return;
}

/*rendering related functions*/
void PartPlateList::render_instance(bool bottom, bool only_current, bool only_body, bool force_background_color, int hover_id, bool show_grid, bool enable_multi_instance)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_grid(bool bottom)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_instance_grid(bool bottom)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_unselected_grid(bool bottom)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_instance_background(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_unselected_background(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_wrapping_detection_area(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_exclude_area(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_instance_exclude_area(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_unselected_exclude_area(bool force_default_color)
{} /* WASM: çizim kodu kaldırıldı */

//render
void PartPlateList::render(bool bottom, bool only_current, bool only_body, int hover_id, bool render_cali, bool show_grid, bool enable_multi_instance)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::render_for_picking_pass()
{} /* WASM: çizim kodu kaldırıldı */

/*int PartPlateList::select_plate_by_hover_id(int hover_id)
{
	int index = hover_id / PartPlate::GRABBER_COUNT;
	int sub_hover_id = hover_id % PartPlate::GRABBER_COUNT;
	if (sub_hover_id == 0) {
		select_plate(index);
	}
	else if (sub_hover_id == 1) {
		if (m_current_plate == 0) {
			select_plate(0);
		}
		else {
			select_plate(index - 1);
		}
	}
	else if (sub_hover_id == 2) {
		if (m_current_plate == (get_plate_count() - 1)) {
			select_plate(m_current_plate);
		}
		else {
			select_plate(index + 1);
		}
	}
	else {
		return -1;
	}
	return 0;
}*/

void PartPlateList::set_render_option(bool bedtype_texture, bool plate_settings)
{} /* WASM: çizim kodu kaldırıldı */

int PartPlateList::select_plate_by_obj(int obj_index, int instance_index)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlateList::calc_bounding_boxes()
{
	m_bounding_box.reset();
	std::vector<PartPlate*>::iterator it = m_plate_list.begin();
	for (it = m_plate_list.begin(); it != m_plate_list.end(); it++) {
		m_bounding_box.merge((*it)->get_bounding_box(true));
	}
}

void PartPlateList::select_plate_view()
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlateList::set_shapes(const Pointfs              &shape,
                               const Pointfs              &exclude_areas,
                               const Pointfs              &wrapping_exclude_areas,
                               const std::vector<Pointfs> &extruder_areas,
                               const std::vector<double>  &extruder_heights,
                               const std::string          &texture_filename,
                               float                       height_to_lid,
                               float                       height_to_rod)
{
	const std::lock_guard<std::mutex> local_lock(m_plates_mutex);
	m_shape = shape;
	m_exclude_areas = exclude_areas;
    m_wrapping_exclude_areas = wrapping_exclude_areas;
	m_extruder_areas = extruder_areas;
	m_extruder_heights = extruder_heights;
	m_height_to_lid = height_to_lid;
	m_height_to_rod = height_to_rod;

	double stride_x = plate_stride_x();
	double stride_y = plate_stride_y();
	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		PartPlate* plate = m_plate_list[i];
		assert(plate != NULL);

		Vec2d pos;

		pos = compute_shape_position(i, m_plate_cols);
		plate->set_shape(shape, exclude_areas, extruder_areas, extruder_heights, pos, height_to_lid, height_to_rod);
	}
	is_load_bedtype_textures = false; //reload textures
    is_load_extruder_only_area_textures = false; // reload textures
	calc_bounding_boxes();

	update_logo_texture_filename(texture_filename);
    update_plate_trans(get_plate_count());

    if (m_plater != nullptr) { // prepare render data, skip in CLI mode where m_plater is null
        ExPolygon poly;
        generate_print_polygon(poly);
        calc_triangles(poly);

        // reset m_wrapping_detection_triangles when change printer
        m_print_polygon = poly;
        m_wrapping_detection_triangles.reset();

		ExPolygon exclude_poly;
        generate_exclude_polygon(exclude_poly);
        calc_exclude_triangles(exclude_poly);

        const BoundingBox &pp_bbox = poly.contour.bounding_box();
        calc_gridlines(poly, pp_bbox);

        // calc_vertex_for_icons(4, m_del_icon);
        calc_vertex_for_icons(0, m_del_icon);
        calc_vertex_for_icons(1, m_orient_icon);
        calc_vertex_for_icons(2, m_arrange_icon);
        calc_vertex_for_icons(3, m_lock_icon);
        calc_vertex_for_icons(4, m_plate_settings_icon);
        calc_vertex_for_icons(5, m_plate_filament_map_icon);
        calc_vertex_for_number(0, false, m_plate_idx_icon);
    }
	return true;
}

void PartPlateList::update_logo_texture_filename(const std::string &texture_filename)
{} /* WASM: çizim kodu kaldırıldı */

/*slice related functions*/
//update current slice context into backgroud slicing process
void PartPlateList::update_slice_context_to_current_plate(BackgroundSlicingProcess& process)
{} /* WASM: çizim kodu kaldırıldı */

//return the current fff print object
Print& PartPlateList::get_current_fff_print() const
{ static std::remove_reference_t<Print> _s; return _s; } /* WASM: çizim kodu kaldırıldı */

//return the slice result
GCodeProcessorResult* PartPlateList::get_current_slice_result() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//invalid all the plater's slice result
void PartPlateList::invalid_all_slice_result()
{} /* WASM: çizim kodu kaldırıldı */

//check whether all plates's slice result valid
bool PartPlateList::is_all_slice_results_valid() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//check whether all plates's slice result valid for print
bool PartPlateList::is_all_slice_results_ready_for_print() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//check whether all plates' slice result valid for export to file
bool PartPlateList::is_all_slice_result_ready_for_export() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//check whether all plates ready for slice
bool PartPlateList::is_all_plates_ready_for_slice() const
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//will create a plate and load gcode, return the plate index
int PartPlateList::create_plate_from_gcode_file(const std::string& filename)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlateList::get_sliced_result(std::vector<bool>& sliced_result, std::vector<std::string>& gcode_paths)
{} /* WASM: çizim kodu kaldırıldı */
//rebuild data which are not serialized after de-serialize
int PartPlateList::rebuild_plates_after_deserialize(std::vector<bool>& previous_sliced_result, std::vector<std::string>& previous_gcode_paths)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

//retruct plates structures after auto-arrangement
int PartPlateList::rebuild_plates_after_arrangement(bool recycle_plates, bool except_locked, int plate_index)
{
	int ret = 0;

	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":before rebuild, plates count %1%, recycle_plates %2%") % m_plate_list.size() % recycle_plates;

	// Capture virtual-plate ownership BEFORE std::sort scrambles obj_id, keyed
	// by ModelObject* (stable across sort). Drop entries whose current bbox no
	// longer overlaps the virtual plate -- ArrangeJob may have just moved them
	// onto a real plate, and we must not re-snap them back.
	std::set<ModelObject*> sticky_virtual_objs;
	if (m_model) {
		BoundingBoxf3 virtual_bbox = unprintable_plate.get_plate_box();
		for (const auto& pr : unprintable_plate.get_obj_and_inst_set()) {
			if (pr.first < 0 || pr.first >= (int)m_model->objects.size())
				continue;
			ModelObject *obj = m_model->objects[pr.first];
			if (!obj || pr.second < 0 || pr.second >= (int)obj->instances.size())
				continue;
			BoundingBoxf3 inst_bbox = obj->instance_convex_hull_bounding_box((size_t)pr.second);
			if (virtual_bbox.intersects(inst_bbox))
				sticky_virtual_objs.insert(obj);
		}
	}

	// sort by arrange_order
	std::sort(m_model->objects.begin(), m_model->objects.end(), [](auto a, auto b) {return a->instances[0]->arrange_order < b->instances[0]->arrange_order; });
	//for (auto object : m_model->objects)
	//	std::sort(object->instances.begin(), object->instances.end(), [](auto a, auto b) {return a->arrange_order < b->arrange_order; });

	// Rewrite inst_set with post-sort obj_id. Run on ANY pre-filter entries
	// (even if all got dropped) -- otherwise stale (obj_id, inst_id) pairs
	// survive and reload_all_objects's sticky_virtual loop re-snaps the
	// just-arranged objects back to the virtual centre.
	if (m_model && !unprintable_plate.get_obj_and_inst_set().empty()) {
		unprintable_plate.clear();
		for (size_t i = 0; i < m_model->objects.size(); ++i) {
			if (!sticky_virtual_objs.count(m_model->objects[i])) continue;
			ModelObject* obj = m_model->objects[i];
			for (size_t j = 0; j < obj->instances.size(); ++j) {
				BoundingBoxf3 bbox = obj->instance_convex_hull_bounding_box(j);
				unprintable_plate.add_instance((int)i, (int)j, false, &bbox);
			}
		}
	}

	ret = reload_all_objects(except_locked, plate_index);

	if (recycle_plates)
	{
		// Sweep all empty non-locked plates (incl. middle ones); plate 0 stays via `i > 0`.
		for (unsigned int i = (unsigned int)m_plate_list.size() - 1; i > 0; --i)
		{
			if (m_plate_list[i]->empty()
				|| !m_plate_list[i]->has_printable_instances())
			{
				//delete it
				BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":delete plate %1% for empty") % i;
				delete_plate(i);
			}
			else if (m_plate_list[i]->is_locked()) {
				continue;
			}
			else
			{
				continue;
			}
		}
	}

#if 0
	if (m_plater != nullptr) {
		// In GUI mode
		wxGetApp().obj_list()->reload_all_plates();
	}
#endif

	if (m_plater)
		m_plater->mark_plate_toolbar_image_dirty();

	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":after rebuild, plates count %1%") % m_plate_list.size();
	return ret;
}

int PartPlateList::store_to_3mf_structure(PlateDataPtrs& plate_data_list, bool with_slice_info, int plate_idx)
{
	int ret = 0;

	plate_data_list.clear();
	plate_data_list.reserve(m_plate_list.size());
	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		PlateData* plate_data_item = new PlateData();
		// TODO: write if needed
		plate_data_item->filament_maps = m_plate_list[i]->get_filament_maps();
		plate_data_item->locked = m_plate_list[i]->m_locked;
		plate_data_item->plate_index = m_plate_list[i]->m_plate_index;
		plate_data_item->plate_name  = m_plate_list[i]->get_plate_name();
		BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1% before load, width %2%, height %3%, size %4%!")
			%(i+1) %m_plate_list[i]->thumbnail_data.width %m_plate_list[i]->thumbnail_data.height %m_plate_list[i]->thumbnail_data.pixels.size();
		plate_data_item->plate_thumbnail.load_from(m_plate_list[i]->thumbnail_data);
		BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1% after load, width %2%, height %3%, size %4%!")
			%(i+1) %plate_data_item->plate_thumbnail.width %plate_data_item->plate_thumbnail.height %plate_data_item->plate_thumbnail.pixels.size();
		plate_data_item->config.apply(*m_plate_list[i]->config());

		if (m_plate_list[i]->no_light_thumbnail_data.is_valid())
			plate_data_item->no_light_thumbnail_file = "valid_no_light";
		if (m_plate_list[i]->top_thumbnail_data.is_valid())
			plate_data_item->top_file = "valid_top";
		if (m_plate_list[i]->pick_thumbnail_data.is_valid())
			plate_data_item->pick_file = "valid_pick";

		if (m_plate_list[i]->obj_to_instance_set.size() > 0)
		{
			for (std::set<std::pair<int, int>>::iterator it = m_plate_list[i]->obj_to_instance_set.begin(); it != m_plate_list[i]->obj_to_instance_set.end(); ++it)
				plate_data_item->objects_and_instances.emplace_back(it->first, it->second);
		}

		BOOST_LOG_TRIVIAL(info) << __FUNCTION__ <<boost::format(": plate %1%, gcode_filename=%2%, with_slice_info=%3%, slice_valid %4%, object item count %5%.") % i %
                                       PathSanitizer::sanitize(m_plate_list[i]->m_gcode_result->filename) % with_slice_info % m_plate_list[i]->is_slice_result_valid() %
                                       plate_data_item->objects_and_instances.size();

		if (with_slice_info) {
			if (m_plate_list[i]->get_slice_result() && m_plate_list[i]->is_slice_result_valid()) {
				// BBS only include current palte_idx
				if (plate_idx == i || plate_idx == PLATE_CURRENT_IDX || plate_idx == PLATE_ALL_IDX) {
					//load calibration thumbnail
					//if (m_plate_list[i]->cali_thumbnail_data.is_valid())
					//	plate_data_item->pattern_file = "valid_pattern";
					if (m_plate_list[i]->cali_bboxes_data.is_valid())
						plate_data_item->pattern_bbox_file = "valid_pattern_bbox";
					plate_data_item->gcode_file       = m_plate_list[i]->m_gcode_result->filename;
					plate_data_item->is_sliced_valid  = true;
					plate_data_item->gcode_prediction = std::to_string(
						(int) m_plate_list[i]->get_slice_result()->print_statistics.modes[static_cast<size_t>(PrintEstimatedStatistics::ETimeMode::Normal)].time);
					plate_data_item->toolpath_outside = m_plate_list[i]->m_gcode_result->toolpath_outside;
                    plate_data_item->timelapse_warning_code = m_plate_list[i]->m_gcode_result->timelapse_warning_code;
                    m_plate_list[i]->set_timelapse_warning_code(plate_data_item->timelapse_warning_code);
					plate_data_item->is_label_object_enabled = m_plate_list[i]->m_gcode_result->label_object_enabled;
                    plate_data_item->limit_filament_maps = m_plate_list[i]->m_gcode_result->limit_filament_maps;
                    plate_data_item->layer_filaments  = m_plate_list[i]->m_gcode_result->layer_filaments;
 					plate_data_item->filament_change_sequence = m_plate_list[i]->m_gcode_result->filament_change_sequence;
                    plate_data_item->nozzle_change_sequence = m_plate_list[i]->m_gcode_result->nozzle_change_sequence;
                    plate_data_item->optimal_assignment = m_plate_list[i]->m_gcode_result->optimal_assignment;
                    plate_data_item->first_layer_time = std::to_string(m_plate_list[i]->cali_bboxes_data.first_layer_time);
					Print *print                      = nullptr;
					m_plate_list[i]->get_print((PrintBase **) &print, nullptr, nullptr);
					if (print) {
						const PrintStatistics &ps = print->print_statistics();
						if (ps.total_weight != 0.0) {
							CNumericLocalesSetter locales_setter;
							plate_data_item->gcode_weight =wxString::Format("%.2f", ps.total_weight).ToStdString();
						}
						plate_data_item->is_support_used = print->is_support_used();
					} else {
						BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format("print is null!");
					}
					//parse filament info
					plate_data_item->parse_filament_info(m_plate_list[i]->get_slice_result());
				} else {
					BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << "slice result = " << m_plate_list[i]->get_slice_result()
										<< ", result valid = " << m_plate_list[i]->is_slice_result_valid();
				}
			}
		}

		plate_data_list.push_back(plate_data_item);
	}
	BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(":stored %1% plates!") % m_plate_list.size();

	return ret;
}

int PartPlateList::load_from_3mf_structure(PlateDataPtrs& plate_data_list, int filament_count)
{
	auto parse_values = [](const std::string& value, const char* seps, auto to_value) {
		using T = decltype(to_value(std::string()));
		std::vector<T> result;
		if (value.empty()) {
			return result;
		}
		std::vector<std::string> tokens;
		boost::split(tokens, value, boost::is_any_of(seps), boost::token_compress_on);
		for (const auto& token : tokens) {
			if (token.empty()) {
				continue;
			}
			try {
				result.emplace_back(to_value(token));
			} catch (...) {
			}
		}
		return result;
	};

	int ret = 0;

	if (plate_data_list.size() <= 0)
	{
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << boost::format(":no plates, should not happen!");
		return -1;
	}
	clear(true, true);
	set_filament_count(filament_count);
	for (unsigned int i = 0; i < (unsigned int)plate_data_list.size(); ++i)
	{
		int index = create_plate(false);
		m_plate_list[index]->m_locked = plate_data_list[i]->locked;
		m_plate_list[index]->config()->apply(plate_data_list[i]->config);
        m_plate_list[index]->set_plate_name(plate_data_list[i]->plate_name);

        // Check filament_map_mode compatibility
        // If quality mode or convenience mode is not supported (all extruders have same type),
        // automatically switch to flush mode
#if 0
        if (!has_different_extruder_types()) {
            FilamentMapMode current_mode = m_plate_list[index]->get_filament_map_mode();
            if (current_mode == FilamentMapMode::fmmAutoForQuality ||
                current_mode == FilamentMapMode::fmmAutoForMatch) {
                m_plate_list[index]->set_filament_map_mode(FilamentMapMode::fmmAutoForFlush);
                BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1% switched to flush mode (quality/convenience mode not supported)") % index;
            }
        }
#endif
		if (plate_data_list[i]->plate_index != index)
		{
			BOOST_LOG_TRIVIAL(warning) << __FUNCTION__ << boost::format(":plate index %1% seems invalid, skip it")% plate_data_list[i]->plate_index;
		}
		BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1%, gcode_file %2%, is_sliced_valid %3%, toolpath_outside %4%, is_support_used %5% is_label_object_enabled %6%") % i %
                                       PathSanitizer::sanitize(plate_data_list[i]->gcode_file) % plate_data_list[i]->is_sliced_valid % plate_data_list[i]->toolpath_outside %
                                       plate_data_list[i]->is_support_used % plate_data_list[i]->is_label_object_enabled;
		//load object and instance from 3mf
		//just test for file correct or not, we will rebuild later
		/*for (std::vector<std::pair<int, int>>::iterator it = plate_data_list[i]->objects_and_instances.begin(); it != plate_data_list[i]->objects_and_instances.end(); ++it)
			m_plate_list[index]->obj_to_instance_set.insert(std::pair(it->first, it->second));*/
		if (!plate_data_list[i]->gcode_file.empty()) {
			m_plate_list[index]->m_gcode_path_from_3mf = plate_data_list[i]->gcode_file;
		}
		GCodeResult* gcode_result = nullptr;
		PrintBase* fff_print = nullptr;
		m_plate_list[index]->get_print(&fff_print, &gcode_result, nullptr);
		PrintStatistics& ps = (dynamic_cast<Print*>(fff_print))->print_statistics();
		gcode_result->print_statistics.modes[static_cast<size_t>(PrintEstimatedStatistics::ETimeMode::Normal)].time = atoi(plate_data_list[i]->gcode_prediction.c_str());
		ps.total_weight = atof(plate_data_list[i]->gcode_weight.c_str());
		ps.total_used_filament = 0.f;
		for (auto filament_item: plate_data_list[i]->slice_filaments_info)
		{
			ps.total_used_filament += filament_item.used_m;
		}
		ps.total_used_filament *= 1000; //koef
		gcode_result->toolpath_outside = plate_data_list[i]->toolpath_outside;
		gcode_result->label_object_enabled = plate_data_list[i]->is_label_object_enabled;
        gcode_result->timelapse_warning_code = plate_data_list[i]->timelapse_warning_code;
		gcode_result->filament_change_sequence = plate_data_list[i]->filament_change_sequence;
		gcode_result->nozzle_change_sequence   = plate_data_list[i]->nozzle_change_sequence;
        m_plate_list[index]->set_timelapse_warning_code(plate_data_list[i]->timelapse_warning_code);
		m_plate_list[index]->slice_filaments_info = plate_data_list[i]->slice_filaments_info;
		gcode_result->warnings = plate_data_list[i]->warnings;
        gcode_result->filament_maps = plate_data_list[i]->filament_maps;

		std::vector<int> nozzle_volume_type_values = parse_values(
			plate_data_list[i]->nozzle_volume_types,
			" ",
			[](const std::string& token) { return std::stoi(token); }
		);

		std::vector<double> nozzle_diameter_values = parse_values(
			plate_data_list[i]->nozzle_diameters,
			" ,",
			[](const std::string& token) { return std::stod(token); }
		);

		std::vector<NozzleVolumeType> extruder_volume_types(nozzle_volume_type_values.size(), NozzleVolumeType::nvtStandard);
		std::vector<double> nozzle_diameters(nozzle_diameter_values.size(), 0.0);

		if (!nozzle_volume_type_values.empty()) {
			for (size_t idx = 0; idx < nozzle_volume_type_values.size(); ++idx) {
				if (nozzle_volume_type_values[idx] >= 0) {
					extruder_volume_types[idx] = static_cast<NozzleVolumeType>(nozzle_volume_type_values[idx]);
				}
			}
		}
		if (!nozzle_diameter_values.empty()) {
			for (size_t idx = 0; idx < nozzle_diameter_values.size(); ++idx) {
				if (nozzle_diameter_values[idx] > 0) {
					nozzle_diameters[idx] = nozzle_diameter_values[idx];
				}
			}
		}

		auto nozzle_infos = MultiNozzleUtils::load_nozzle_infos_with_compatibility(
			plate_data_list[i]->nozzles_info,
			plate_data_list[i]->slice_filaments_info,
			plate_data_list[i]->filament_maps,
			extruder_volume_types,
			nozzle_diameter_values
		);

		std::vector<int> fil_seq(plate_data_list[i]->filament_change_sequence.begin(), plate_data_list[i]->filament_change_sequence.end());
		std::vector<int> noz_seq(plate_data_list[i]->nozzle_change_sequence.begin(), plate_data_list[i]->nozzle_change_sequence.end());
		bool enable_filament_dynamic_map =false;
        if (plate_data_list[i]->config.has("enable_filament_dynamic_map"))
            enable_filament_dynamic_map = plate_data_list[i]->config.option<ConfigOptionBool>("enable_filament_dynamic_map")->value;
		auto group_result = MultiNozzleUtils::StaticNozzleGroupResult::create(plate_data_list[i]->slice_filaments_info, nozzle_infos, fil_seq, noz_seq,enable_filament_dynamic_map);
        if (group_result)
            gcode_result->nozzle_group_result = std::make_shared<MultiNozzleUtils::StaticNozzleGroupResult>(group_result.value());
        else
            gcode_result->nozzle_group_result = nullptr;


		if (m_plater && !plate_data_list[i]->thumbnail_file.empty()) {
            BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1%, load thumbnail from %2%.") % (i + 1) % PathSanitizer::sanitize(plate_data_list[i]->thumbnail_file);
			if (boost::filesystem::exists(plate_data_list[i]->thumbnail_file)) {
				m_plate_list[index]->load_thumbnail_data(plate_data_list[i]->thumbnail_file, m_plate_list[index]->thumbnail_data);
				BOOST_LOG_TRIVIAL(info) << __FUNCTION__ <<boost::format(": plate %1% after load, width %2%, height %3%, size %4%!")
					%(i+1) %m_plate_list[index]->thumbnail_data.width %m_plate_list[index]->thumbnail_data.height %m_plate_list[index]->thumbnail_data.pixels.size();
			}
		}

		if (m_plater && !plate_data_list[i]->no_light_thumbnail_file.empty()) {
			if (boost::filesystem::exists(plate_data_list[i]->no_light_thumbnail_file)) {
                BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1%, load no_light_thumbnail_file from %2%.") % (i + 1) % PathSanitizer::sanitize(plate_data_list[i]->no_light_thumbnail_file);
				m_plate_list[index]->load_thumbnail_data(plate_data_list[i]->no_light_thumbnail_file, m_plate_list[index]->no_light_thumbnail_data);
			}
		}

		/*if (m_plater && !plate_data_list[i]->pattern_file.empty()) {
			if (boost::filesystem::exists(plate_data_list[i]->pattern_file)) {
				//no need to load pattern data currently
				//m_plate_list[index]->load_pattern_thumbnail_data(plate_data_list[i]->pattern_file);
			}
		}*/
		if (m_plater && !plate_data_list[i]->top_file.empty()) {
			if (boost::filesystem::exists(plate_data_list[i]->top_file)) {
                BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1%, load top_thumbnail from %2%.") % (i + 1) % PathSanitizer::sanitize(plate_data_list[i]->top_file);
				m_plate_list[index]->load_thumbnail_data(plate_data_list[i]->top_file, m_plate_list[index]->top_thumbnail_data);
			}
		}
		if (m_plater && !plate_data_list[i]->pick_file.empty()) {
			if (boost::filesystem::exists(plate_data_list[i]->pick_file)) {
                BOOST_LOG_TRIVIAL(info) << __FUNCTION__ << boost::format(": plate %1%, load pick_thumbnail from %2%.") % (i + 1) % PathSanitizer::sanitize(plate_data_list[i]->pick_file);
				m_plate_list[index]->load_thumbnail_data(plate_data_list[i]->pick_file, m_plate_list[index]->pick_thumbnail_data);
			}
		}
		if (m_plater && !plate_data_list[i]->pattern_bbox_file.empty()) {
			if (boost::filesystem::exists(plate_data_list[i]->pattern_bbox_file)) {
				m_plate_list[index]->load_pattern_box_data(plate_data_list[i]->pattern_bbox_file);
			}
		}

	}
	print();
	ret = reload_all_objects();
	print();

	return ret;
}

//load gcode files
int PartPlateList::load_gcode_files()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlateList::print() const
{
	BOOST_LOG_TRIVIAL(trace) << __FUNCTION__ << boost::format("PartPlateList %1%, m_plate_count %2%, current_plate %3%, print_count %4%, current print index %5%, plate cols %6%") % this % m_plate_count % m_current_plate % m_print_list.size() % m_print_index % m_plate_cols;
	BOOST_LOG_TRIVIAL(trace) << boost::format("m_plate_width %1%, m_plate_depth %2%, m_plate_height %3%, plate count %4%\nplate list:") % m_plate_width % m_plate_depth % m_plate_height % m_plate_list.size();
	for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
	{
		BOOST_LOG_TRIVIAL(trace) << boost::format("the %1%th plate") % i;
		m_plate_list[i]->print();
	}
	BOOST_LOG_TRIVIAL(trace) << boost::format("the unprintable plate:");
	unprintable_plate.print();

	flush_logs();
	return;
}

bool PartPlateList::is_load_bedtype_textures = false;
bool PartPlateList::is_load_extruder_only_area_textures = false;
bool PartPlateList::is_load_cali_texture     = false;

void PartPlateList::BedTextureInfo::TexturePart::update_buffer()
{
	if (w == 0 || h == 0) {
		return;
	}

	Pointfs rectangle;
	rectangle.push_back(Vec2d(x, y));
	rectangle.push_back(Vec2d(x+w, y));
	rectangle.push_back(Vec2d(x+w, y+h));
	rectangle.push_back(Vec2d(x, y+h));
	ExPolygon poly;

	for (int i = 0; i < 4; i++) {
		const Vec2d & p = rectangle[i];
		for (auto& p : rectangle) {
			Vec2d pp = Vec2d(p.x() + offset.x(), p.y() + offset.y());
			poly.contour.append({ scale_(pp(0)), scale_(pp(1)) });
		}
	}

	if (!buffer) buffer = new GLModel();
    buffer->reset();
    if (!buffer->init_model_from_poly(triangulate_expolygon_2f(poly, NORMALS_UP), GROUND_Z + 0.02f)) {
		BOOST_LOG_TRIVIAL(error) << __FUNCTION__ << ":Unable to create buffer triangles\n";
	}
}

void PartPlateList::BedTextureInfo::TexturePart::reset()
{
    if (texture) {
        texture->reset();
        delete texture;
    }
    if (buffer) {
        release_vbo();
        delete buffer;
    }
}

void PartPlateList::BedTextureInfo::TexturePart::release_vbo()
{
    if (vbo_id != 0) {
        glsafe(::glDeleteBuffers(1, &vbo_id));
        vbo_id = 0;
    }
}

void PartPlateList::BedTextureInfo::reset()
{
    for (size_t i = 0; i < parts.size(); i++)
        parts[i].reset();
}

void PartPlateList::init_bed_type_info()
{} /* WASM: çizim kodu kaldırıldı */

bool PartPlateList::calc_extruder_only_area(Rect &left_only_rect, Rect &right_only_rect)
{ return {}; } /* WASM: çizim kodu kaldırıldı */

bool PartPlateList::init_extruder_only_area_info()
{ return {}; } /* WASM: çizim kodu kaldırıldı */

void PartPlateList::load_bedtype_textures()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::load_extruder_only_area_textures() {} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::init_cali_texture_info()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::load_cali_textures()
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::on_extruder_count_changed(int extruder_count)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::set_filament_count(int filament_count)
{
    m_filament_count = filament_count;
    for (unsigned int i = 0; i < (unsigned int)m_plate_list.size(); ++i)
    {
        m_plate_list[i]->set_filament_count(filament_count);
    }
    BOOST_LOG_TRIVIAL(info) << boost::format("%1%: filament_count=%2%")% __FUNCTION__ %filament_count;
}

void PartPlateList::on_filament_added(int filament_count)
{} /* WASM: çizim kodu kaldırıldı */

void PartPlateList::on_filament_deleted(int filament_count, int filament_id)
{} /* WASM: çizim kodu kaldırıldı */

}//end namespace GUI
}//end namespace slic3r
