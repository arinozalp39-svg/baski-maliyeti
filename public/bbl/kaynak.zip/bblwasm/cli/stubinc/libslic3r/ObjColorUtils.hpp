#pragma once
// WASM: OpenCV yok — renk kümeleme devre dışı (dilimleme sonucunu etkilemez).
#include <vector>
#include <map>
#include <unordered_map>
#include <string>
#include "libslic3r/Color.hpp"
namespace Slic3r { class Model; struct ObjDialogInOut; struct VolumeColorInfo; }
bool obj_color_deal_algo(std::vector<Slic3r::RGBA> &input_colors, std::vector<Slic3r::RGBA> &cluster_colors_from_algo,
                         std::vector<int> &cluster_labels_from_algo, char &cluster_number, int max_cluster);
bool extract_colors_to_obj_dialog(Slic3r::Model* model, const std::map<int, std::vector<std::string>>& color_group_map,
    const std::unordered_map<int, Slic3r::VolumeColorInfo>& volume_color_data, Slic3r::ObjDialogInOut& out);
