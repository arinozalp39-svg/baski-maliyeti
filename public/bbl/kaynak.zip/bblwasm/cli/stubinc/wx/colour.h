#pragma once
class wxColour {
    unsigned char r_ = 0, g_ = 0, b_ = 0, a_ = 255;
public:
    wxColour() {}
    wxColour(unsigned char r, unsigned char g, unsigned char b, unsigned char a = 255) : r_(r), g_(g), b_(b), a_(a) {}
    unsigned char Red() const { return r_; } unsigned char Green() const { return g_; }
    unsigned char Blue() const { return b_; } unsigned char Alpha() const { return a_; }
};
