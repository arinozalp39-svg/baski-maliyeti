#pragma once
#include "gui_stubs.hpp"
struct wxFileName { static wxString GetTempDir() { return wxString("/tmp"); } };
