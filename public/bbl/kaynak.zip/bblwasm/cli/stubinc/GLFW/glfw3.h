#pragma once
// WASM: OpenGL yok — glfwInit başarısız döner, CLI küçük resim üretmeyi atlar.
typedef struct GLFWwindow GLFWwindow;
typedef void (*GLFWerrorfun)(int, const char*);
#define GLFW_CONTEXT_VERSION_MAJOR 1
#define GLFW_CONTEXT_VERSION_MINOR 2
#define GLFW_RED_BITS 3
#define GLFW_GREEN_BITS 4
#define GLFW_BLUE_BITS 5
#define GLFW_ALPHA_BITS 6
#define GLFW_VISIBLE 7
#define GLFW_OPENGL_PROFILE 8
#define GLFW_OPENGL_CORE_PROFILE 9
#define GLFW_OPENGL_COMPAT_PROFILE 10
#define GLFW_OPENGL_FORWARD_COMPAT 11
#define GLFW_CONTEXT_CREATION_API 12
#define GLFW_OSMESA_CONTEXT_API 13
#define GL_TRUE 1
#define GLFW_FALSE 0
#define GLFW_TRUE 1
#define GLFW_AUTO_POLL_EVENTS 14
inline void glfwGetVersion(int* a, int* b, int* c) { *a = 3; *b = 3; *c = 0; }
inline GLFWerrorfun glfwSetErrorCallback(GLFWerrorfun) { return nullptr; }
inline int glfwInit() { return 0; }
inline int glfwGetError(const char**) { return 1; }
inline void glfwWindowHint(int, int) {}
inline GLFWwindow* glfwCreateWindow(int, int, const char*, void*, void*) { return nullptr; }
inline void glfwMakeContextCurrent(GLFWwindow*) {}
inline void glfwDestroyWindow(GLFWwindow*) {}
inline void glfwTerminate() {}
